package com.xenomized;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/** Draws your flat 2D picture, cover-fitted to the screen. */
public final class XenoBackground {
    private static final Identifier BG = Identifier.of("xenomized", "textures/gui/title_bg.png");
    private static final int BG_W = 1920;
    private static final int BG_H = 1080;

    private XenoBackground() {}

    public static void draw(DrawContext ctx, int width, int height) {
        if (width <= 0 || height <= 0) return;
        float screenAspect = width / (float) height;
        float imgAspect = BG_W / (float) BG_H;
        int regionW;
        int regionH;
        float u;
        float v;
        if (screenAspect > imgAspect) {
            regionW = BG_W;
            regionH = Math.round(BG_W / screenAspect);
            u = 0f;
            v = (BG_H - regionH) / 2f;
        } else {
            regionH = BG_H;
            regionW = Math.round(BG_H * screenAspect);
            v = 0f;
            u = (BG_W - regionW) / 2f;
        }
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, BG, 0, 0, u, v, width, height,
                regionW, regionH, BG_W, BG_H);
        ctx.fill(0, 0, width, height, 0x50000000); // darken so text stays readable
    }
}
