package com.xenomized;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayDeque;

/** The HUD overlays: FPS, CPS, coordinates, ping, keystrokes and armor status. */
public final class XenoHud {
    private XenoHud() {}

    public enum Element {
        FPS("fps", "FPS counter", 0.01f, 0.02f),
        CPS("cps", "CPS counter", 0.01f, 0.09f),
        COORDS("coords", "Coordinates", 0.01f, 0.16f),
        PING("ping", "Ping", 0.01f, 0.27f),
        KEYS("keys", "Keystrokes", 0.01f, 0.55f),
        ARMOR("armor", "Armor status", 0.90f, 0.40f);

        public final String id;
        public final String label;
        public final float dx;
        public final float dy;

        Element(String id, String label, float dx, float dy) {
            this.id = id;
            this.label = label;
            this.dx = dx;
            this.dy = dy;
        }

        public boolean enabled() {
            XenomizedConfig c = XenomizedConfig.cfg;
            return switch (this) {
                case FPS -> c.hudFps;
                case CPS -> c.hudCps;
                case COORDS -> c.hudCoords;
                case PING -> c.hudPing;
                case KEYS -> c.hudKeys;
                case ARMOR -> c.hudArmor;
            };
        }

        public void setEnabled(boolean on) {
            XenomizedConfig c = XenomizedConfig.cfg;
            switch (this) {
                case FPS -> c.hudFps = on;
                case CPS -> c.hudCps = on;
                case COORDS -> c.hudCoords = on;
                case PING -> c.hudPing = on;
                case KEYS -> c.hudKeys = on;
                case ARMOR -> c.hudArmor = on;
            }
        }
    }

    // ---------- CPS tracking (counted each client tick) ----------
    private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
    private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
    private static boolean prevLeft;
    private static boolean prevRight;

    public static void tick(MinecraftClient c) {
        long now = System.currentTimeMillis();
        boolean l = c.options.attackKey.isPressed();
        boolean r = c.options.useKey.isPressed();
        if (l && !prevLeft) LEFT.addLast(now);
        if (r && !prevRight) RIGHT.addLast(now);
        prevLeft = l;
        prevRight = r;
        while (!LEFT.isEmpty() && now - LEFT.peekFirst() > 1000) LEFT.removeFirst();
        while (!RIGHT.isEmpty() && now - RIGHT.peekFirst() > 1000) RIGHT.removeFirst();
    }

    // ---------- text for each element ----------
    private static String fpsText() {
        return "FPS: " + MinecraftClient.getInstance().getCurrentFps();
    }

    private static String cpsText() {
        return "CPS: " + LEFT.size() + " | " + RIGHT.size();
    }

    private static String pingText() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null && c.getNetworkHandler() != null) {
            PlayerListEntry e = c.getNetworkHandler().getPlayerListEntry(c.player.getUuid());
            if (e != null) return "Ping: " + e.getLatency() + " ms";
        }
        return "Ping: -";
    }

    private static String[] coordsLines() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null) return new String[]{"XYZ: 0 64 0", "Facing: North"};
        String face = c.player.getHorizontalFacing().name();
        face = face.substring(0, 1) + face.substring(1).toLowerCase();
        return new String[]{
                "XYZ: " + (int) Math.floor(c.player.getX()) + " " + (int) Math.floor(c.player.getY())
                        + " " + (int) Math.floor(c.player.getZ()),
                "Facing: " + face
        };
    }

    // ---------- sizes and positions ----------
    private static final int KEY = 18;
    private static final int GAP = 2;

    public static int[] size(Element e) {
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        return switch (e) {
            case FPS -> new int[]{tr.getWidth(fpsText()) + 8, 14};
            case CPS -> new int[]{tr.getWidth(cpsText()) + 8, 14};
            case PING -> new int[]{tr.getWidth(pingText()) + 8, 14};
            case COORDS -> {
                String[] l = coordsLines();
                yield new int[]{Math.max(tr.getWidth(l[0]), tr.getWidth(l[1])) + 8, 25};
            }
            case KEYS -> new int[]{3 * KEY + 2 * GAP, 2 * KEY + 2 * GAP + 12 + GAP + 14};
            case ARMOR -> new int[]{22 + tr.getWidth("0000") + 4, 4 * 18 + 4};
        };
    }

    public static int[] position(Element e, int sw, int sh, int[] size) {
        float[] f = XenomizedConfig.cfg.hudPos.get(e.id);
        if (f == null || f.length < 2) f = new float[]{e.dx, e.dy};
        int x = MathHelper.clamp(Math.round(f[0] * sw), 0, Math.max(0, sw - size[0]));
        int y = MathHelper.clamp(Math.round(f[1] * sh), 0, Math.max(0, sh - size[1]));
        return new int[]{x, y};
    }

    public static void setPosition(Element e, float fx, float fy) {
        XenomizedConfig.cfg.hudPos.put(e.id, new float[]{fx, fy});
        XenomizedConfig.save();
    }

    // ---------- drawing ----------
    public static void render(DrawContext ctx) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.options.hudHidden) return;
        int sw = c.getWindow().getScaledWidth();
        int sh = c.getWindow().getScaledHeight();
        for (Element e : Element.values()) {
            if (!e.enabled()) continue;
            int[] s = size(e);
            int[] p = position(e, sw, sh, s);
            draw(ctx, e, p[0], p[1]);
        }
    }

    private static void text(DrawContext ctx, TextRenderer tr, String s, int x, int y) {
        ctx.drawTextWithShadow(tr, Text.literal(s), x, y, 0xFFFFFFFF);
    }

    public static void draw(DrawContext ctx, Element e, int x, int y) {
        MinecraftClient c = MinecraftClient.getInstance();
        TextRenderer tr = c.textRenderer;
        int[] s = size(e);
        if (XenomizedConfig.cfg.hudBackground && e != Element.KEYS && e != Element.ARMOR) {
            Ui.rounded(ctx, x, y, s[0], s[1], 0x66000000);
        }
        switch (e) {
            case FPS -> text(ctx, tr, fpsText(), x + 4, y + 3);
            case CPS -> text(ctx, tr, cpsText(), x + 4, y + 3);
            case PING -> text(ctx, tr, pingText(), x + 4, y + 3);
            case COORDS -> {
                String[] l = coordsLines();
                text(ctx, tr, l[0], x + 4, y + 3);
                text(ctx, tr, l[1], x + 4, y + 14);
            }
            case KEYS -> drawKeys(ctx, tr, x, y, c);
            case ARMOR -> drawArmor(ctx, tr, x, y, c);
        }
    }

    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h, String label, boolean pressed) {
        Ui.rounded(ctx, x, y, w, h, pressed ? 0xCCFFFFFF : 0x80000000);
        int tx = x + (w - tr.getWidth(label)) / 2;
        int ty = y + (h - 8) / 2;
        ctx.drawTextWithShadow(tr, Text.literal(label), tx, ty, pressed ? 0xFF000000 : 0xFFFFFFFF);
    }

    private static void drawKeys(DrawContext ctx, TextRenderer tr, int x, int y, MinecraftClient c) {
        boolean live = c.player != null && c.currentScreen == null;
        key(ctx, tr, x + KEY + GAP, y, KEY, KEY, "W", live && c.options.forwardKey.isPressed());
        key(ctx, tr, x, y + KEY + GAP, KEY, KEY, "A", live && c.options.leftKey.isPressed());
        key(ctx, tr, x + KEY + GAP, y + KEY + GAP, KEY, KEY, "S", live && c.options.backKey.isPressed());
        key(ctx, tr, x + 2 * (KEY + GAP), y + KEY + GAP, KEY, KEY, "D", live && c.options.rightKey.isPressed());
        int total = 3 * KEY + 2 * GAP;
        key(ctx, tr, x, y + 2 * (KEY + GAP), total, 12, "SPACE", live && c.options.jumpKey.isPressed());
        int my = y + 2 * (KEY + GAP) + 12 + GAP;
        int mw = (total - GAP) / 2;
        key(ctx, tr, x, my, mw, 14, "LMB", live && c.options.attackKey.isPressed());
        key(ctx, tr, x + mw + GAP, my, mw, 14, "RMB", live && c.options.useKey.isPressed());
    }

    private static void drawArmor(DrawContext ctx, TextRenderer tr, int x, int y, MinecraftClient c) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (int i = 0; i < 4; i++) {
            int iy = y + 2 + i * 18;
            if (c.player != null) {
                ItemStack st = c.player.getEquippedStack(slots[i]);
                if (!st.isEmpty()) {
                    ctx.drawItem(st, x + 2, iy);
                    if (st.isDamageable()) {
                        int left = st.getMaxDamage() - st.getDamage();
                        float ratio = left / (float) st.getMaxDamage();
                        int col = ratio > 0.5f ? 0xFF55FF55 : (ratio > 0.2f ? 0xFFFFFF55 : 0xFFFF5555);
                        ctx.drawTextWithShadow(tr, Text.literal(String.valueOf(left)), x + 22, iy + 4, col);
                    }
                    continue;
                }
            }
            Ui.rounded(ctx, x + 2, iy, 16, 16, 0x33FFFFFF); // empty slot
        }
    }
}
