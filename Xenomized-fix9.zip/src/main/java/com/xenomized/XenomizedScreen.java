package com.xenomized;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Xenomized dashboard: sidebar sections on the left, the chosen page on the right. */
public class XenomizedScreen extends Screen {
    private enum Page {
        PERFORMANCE("Performance", "Core settings. Apply while Boost is ON."),
        VISUALS("Visuals", "Cut eye candy. Apply while Boost is ON."),
        CULLING("Entity culling", "Stop drawing far away entities."),
        LIMITS("Stack limits", "Trap spam: draw only a few per pile."),
        PRESETS("Presets", "One tap setups."),
        HUD_ELEMENTS("HUD elements", "Choose what shows on screen."),
        HUD_LAYOUT("HUD layout", "Move and style your HUD."),
        STYLE("Style", "Colors, title screen and sounds.");

        final String title;
        final String desc;

        Page(String title, String desc) {
            this.title = title;
            this.desc = desc;
        }
    }

    private static final int ROW = 26;
    private static final int SIDE_W = 104;
    private static Page current = Page.PERFORMANCE;

    private final Screen parent;
    private int px, py, pw, ph, itemH;

    public XenomizedScreen(Screen parent) {
        super(Text.literal("Xenomized"));
        this.parent = parent;
    }

    // ---------- helpers ----------
    private void add(ClickableWidget w) { addDrawableChild(w); }

    private static Text onOff(boolean v) {
        return Text.literal(v ? "ON" : "OFF").formatted(v ? Formatting.GREEN : Formatting.RED);
    }

    private FancyButton btn(int x, int y, int w, String label, Supplier<Text> value, Runnable action) {
        return new FancyButton(x, y, w, 22, () -> Text.literal(label), value, null, action);
    }

    private FancyButton toggle(int x, int y, int w, String label, BooleanSupplier get,
                               Consumer<Boolean> set, Runnable after) {
        return btn(x, y, w, label, () -> onOff(get.getAsBoolean()), () -> {
            set.accept(!get.getAsBoolean());
            after.run();
        });
    }

    private FancyButton cycle(int x, int y, int w, String label, int[] values, IntSupplier get,
                              IntConsumer set, IntFunction<String> fmt, Runnable after) {
        return btn(x, y, w, label,
                () -> Text.literal(fmt.apply(get.getAsInt())).formatted(Formatting.YELLOW),
                () -> {
                    int cur = get.getAsInt();
                    int idx = 0;
                    for (int i = 0; i < values.length; i++) if (values[i] == cur) idx = i;
                    set.accept(values[(idx + 1) % values.length]);
                    after.run();
                });
    }

    private static String limitText(int v) { return v == 0 ? "Off" : "Max " + v; }

    /** Y position of a sidebar page, including the small group labels above the first page of each group. */
    private int sideY(Page p) {
        int y = py + 38;
        for (Page q : Page.values()) {
            if (q.ordinal() == 0 || q.ordinal() == 5 || q.ordinal() == 7) y += 12;
            if (q == p) return y;
            y += itemH + 3;
        }
        return y;
    }

    // ---------- layout ----------
    @Override
    protected void init() {
        pw = Math.min(width - 12, 420);
        ph = Math.min(height - 12, 250);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        itemH = Math.max(12, Math.min(20, (ph - 60 - 36) / 8 - 3));

        // header: done
        add(new FancyButton(px + pw - 58, py + 4, 50, 18, () -> Text.literal("Done"), null, null, this::close));

        // sidebar
        for (Page p : Page.values()) {
            add(new FancyButton(px + 6, sideY(p), SIDE_W - 12, itemH,
                    () -> Text.literal(p.title), null,
                    () -> current == p,
                    () -> { current = p; clearAndInit(); }));
        }

        // content
        XenomizedConfig c = XenomizedConfig.cfg;
        int cx = px + SIDE_W + 14;
        int cw = pw - SIDE_W - 28;
        int y = py + 58;
        Runnable re = XenomizedConfig::reapply;
        Runnable save = XenomizedConfig::save;

        switch (current) {
            case PERFORMANCE -> {
                add(btn(cx, y, cw, "FPS Boost", () -> onOff(c.enabled), () -> {
                    c.enabled = !c.enabled;
                    if (c.enabled) XenomizedConfig.apply(); else XenomizedConfig.restore();
                })); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Render distance", 2, 16, 1, " chunks",
                        () -> c.renderDistance, v -> c.renderDistance = v, re)); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Simulation distance", 5, 16, 1, " chunks",
                        () -> c.simDistance, v -> c.simDistance = v, re)); y += ROW;
                add(cycle(cx, y, cw, "Max FPS", new int[]{30, 60, 120, 260}, () -> c.maxFps,
                        v -> c.maxFps = v, v -> v >= 260 ? "Unlimited" : String.valueOf(v), re)); y += ROW;
                add(toggle(cx, y, cw, "Fast graphics", () -> c.fastGraphics, v -> c.fastGraphics = v, re));
            }
            case VISUALS -> {
                add(toggle(cx, y, cw, "Minimal particles", () -> c.minimalParticles, v -> c.minimalParticles = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Clouds off", () -> c.noClouds, v -> c.noClouds = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Entity shadows off", () -> c.noShadows, v -> c.noShadows = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Smooth lighting off", () -> c.noSmoothLighting, v -> c.noSmoothLighting = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Biome blend off", () -> c.noBiomeBlend, v -> c.noBiomeBlend = v, re));
            }
            case CULLING -> {
                add(toggle(cx, y, cw, "Entity culling", () -> c.cullEntities, v -> c.cullEntities = v, save)); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Cull distance", 16, 128, 8, " blocks",
                        () -> c.cullDistance, v -> c.cullDistance = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Cull dropped items closer", () -> c.cullItems, v -> c.cullItems = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Cull armor stands closer", () -> c.cullArmorStands, v -> c.cullArmorStands = v, save));
            }
            case LIMITS -> {
                int[] lim = {0, 1, 3};
                add(cycle(cx, y, cw, "Armor stands", lim, () -> c.limitArmorStands,
                        v -> c.limitArmorStands = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "TNT minecarts", lim, () -> c.limitTntMinecarts,
                        v -> c.limitTntMinecarts = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "Wind charges", lim, () -> c.limitWindCharges,
                        v -> c.limitWindCharges = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "Trigger when pile is over", new int[]{5, 10, 20}, () -> c.threshold,
                        v -> c.threshold = v, v -> String.valueOf(v), save));
            }
            case PRESETS -> {
                add(btn(cx, y, cw, "Balanced", () -> Text.literal("Smooth + pretty").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetBalanced(); clearAndInit();
                })); y += ROW;
                add(btn(cx, y, cw, "Max FPS", () -> Text.literal("Potato mode").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetMax(); clearAndInit();
                })); y += ROW;
                add(btn(cx, y, cw, "Restore my settings", () -> Text.literal("Undo all").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.resetAll(); clearAndInit();
                }));
            }
            case HUD_ELEMENTS -> {
                for (XenoHud.Element e : XenoHud.Element.values()) {
                    add(toggle(cx, y, cw, e.label, e::enabled, e::setEnabled, save));
                    y += ROW;
                }
            }
            case HUD_LAYOUT -> {
                add(btn(cx, y, cw, "Edit layout", () -> Text.literal("Drag to move >").formatted(Formatting.AQUA),
                        () -> client.setScreen(new HudEditorScreen(this)))); y += ROW;
                add(toggle(cx, y, cw, "Background boxes", () -> c.hudBackground, v -> c.hudBackground = v, save)); y += ROW;
                add(btn(cx, y, cw, "Reset positions", () -> Text.literal("Default spots").formatted(Formatting.GRAY), () -> {
                    c.hudPos.clear();
                    XenomizedConfig.save();
                }));
            }
            case STYLE -> {
                add(new FancyButton(cx, y, cw, 22, () -> Text.literal("Accent color"),
                        () -> Text.literal(Ui.PALETTE_NAMES[Ui.accentIndex()]).formatted(Formatting.AQUA),
                        null, () -> {
                            c.accent = (c.accent + 1) % Ui.PALETTE.length;
                            XenomizedConfig.save();
                            clearAndInit();
                        })); y += ROW;
                add(toggle(cx, y, cw, "Xeno title screen", () -> c.customTitle, v -> c.customTitle = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Your image on all menus", () -> c.menuBackground, v -> c.menuBackground = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Click sounds", () -> c.clickSound, v -> c.clickSound = v, save));
            }
        }
    }

    // ---------- drawing ----------
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xC0080810);
        Ui.glass(ctx, px, py, pw, ph, false);
        ctx.fill(px + SIDE_W, py + 26, px + SIDE_W + 1, py + ph - 2, 0x33FFFFFF);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;
        int acc = Ui.accent();

        // animated header line: a wave between the accent and violet
        int violet = 0xFFB060FF;
        float time = System.currentTimeMillis() / 700f;
        for (int x = 2; x < pw - 2; x += 4) {
            float t = 0.5f + 0.5f * (float) Math.sin(time + x * 0.03);
            ctx.fill(px + x, py + 26, px + x + 4, py + 27, Ui.lerp(acc, violet, t));
        }

        // group labels in the sidebar
        ctx.drawTextWithShadow(tr, Text.literal("BOOST").formatted(Formatting.DARK_GRAY), px + 10, sideY(Page.PERFORMANCE) - 11, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, Text.literal("HUD").formatted(Formatting.DARK_GRAY), px + 10, sideY(Page.HUD_ELEMENTS) - 11, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, Text.literal("LOOK").formatted(Formatting.DARK_GRAY), px + 10, sideY(Page.STYLE) - 11, 0xFFFFFFFF);

        // header title
        ctx.drawTextWithShadow(tr, Text.literal("XENOMIZED").formatted(Formatting.BOLD), px + 12, py + 9, acc);

        // page title + description
        int cx = px + SIDE_W + 14;
        int maxW = pw - SIDE_W - 28;
        ctx.drawTextWithShadow(tr, Text.literal(current.title).formatted(Formatting.BOLD, Formatting.WHITE),
                cx, py + 32, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth(current.desc, maxW)).formatted(Formatting.GRAY),
                cx, py + 42, 0xFFFFFFFF);

        if (current == Page.LIMITS) {
            ctx.drawTextWithShadow(tr,
                    Text.literal(tr.trimToWidth("Visual only. Hitboxes and server unchanged.", maxW)).formatted(Formatting.DARK_GRAY),
                    cx, py + 58 + ROW * 4 + 4, 0xFFFFFFFF);
        }
    }

    @Override
    public void close() {
        XenomizedConfig.save();
        client.setScreen(parent);
    }
}
