package com.xenomized;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

/** Liquid glass button: translucent, lifts and glows on hover, clicks with a sound. */
public class FancyButton extends ClickableWidget {
    private final Supplier<Text> label;
    private final Supplier<Text> value;
    private final BooleanSupplier selected;
    private final Runnable action;
    private final Supplier<Text> caption;
    /** Thin white stroke style, used on the title screen. */
    public boolean stroked = false;

    public FancyButton(int x, int y, int w, int h, Supplier<Text> label, Supplier<Text> value,
                       BooleanSupplier selected, Runnable action) {
        this(x, y, w, h, label, value, selected, action, null);
    }

    public FancyButton(int x, int y, int w, int h, Supplier<Text> label, Supplier<Text> value,
                       BooleanSupplier selected, Runnable action, Supplier<Text> caption) {
        super(x, y, w, h, Text.empty());
        this.label = label;
        this.value = value;
        this.selected = selected;
        this.action = action;
        this.caption = caption;
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        boolean hot = isHovered();
        boolean sel = selected != null && selected.getAsBoolean();
        int x = getX();
        int y = getY() - (hot ? 1 : 0);
        int w = getWidth();
        int h = getHeight();
        if (stroked) {
            if (hot) ctx.fill(x - 2, y - 2, x + w + 2, y + h + 2, Ui.withAlpha(Ui.accent(), 0x18));
            Ui.panel(ctx, x, y, w, h, hot ? 0x66101018 : 0x33000000, 0xFFFFFFFF);
        } else {
            Ui.glass(ctx, x, y, w, h, hot || sel);
        }
        if (sel) ctx.fill(x, y + 3, x + 2, y + h - 3, Ui.accent());

        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int ty = y + (h - 8) / 2;
        if (caption != null) {
            ctx.drawTextWithShadow(tr, caption.get(), x + 8, y + 3, 0xFFFFFFFF);
            ty = y + h - 11;
        }
        ctx.drawTextWithShadow(tr, label.get(), x + 8, ty, 0xFFFFFFFF);
        if (value != null) {
            Text v = value.get();
            ctx.drawTextWithShadow(tr, v, x + w - 8 - tr.getWidth(v), ty, 0xFFFFFFFF);
        }
    }

    @Override
    public void onClick(Click click, boolean doubled) {
        if (XenomizedConfig.cfg.clickSound) {
            MinecraftClient.getInstance().getSoundManager()
                    .play(PositionedSoundInstance.ui(SoundEvents.UI_BUTTON_CLICK, 1.0f));
        }
        action.run();
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        appendDefaultNarrations(builder);
    }
}
