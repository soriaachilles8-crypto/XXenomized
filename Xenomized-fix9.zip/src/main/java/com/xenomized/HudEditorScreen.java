package com.xenomized;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Drag your HUD pieces where you want them. Tap the chips at the bottom to turn pieces on or off. */
public class HudEditorScreen extends Screen {
    private final Screen parent;

    public HudEditorScreen(Screen parent) {
        super(Text.literal("HUD Editor"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        // the draggable pieces
        for (XenoHud.Element e : XenoHud.Element.values()) {
            if (!e.enabled()) continue;
            int[] s = XenoHud.size(e);
            int[] p = XenoHud.position(e, width, height, s);
            addDrawableChild(new HudDragWidget(e, p[0], p[1], s[0], s[1], width, height));
        }

        // on/off chips
        XenoHud.Element[] all = XenoHud.Element.values();
        int chipW = Math.min(58, (width - 24) / all.length - 4);
        int total = all.length * (chipW + 4) - 4;
        int x = (width - total) / 2;
        int y = height - 52;
        for (XenoHud.Element e : all) {
            addDrawableChild(new FancyButton(x, y, chipW, 16,
                    () -> Text.literal(shortName(e)), null, e::enabled,
                    () -> {
                        e.setEnabled(!e.enabled());
                        XenomizedConfig.save();
                        clearAndInit();
                    }));
            x += chipW + 4;
        }

        // reset + done
        int bw = 90;
        addDrawableChild(new FancyButton(width / 2 - bw - 4, height - 30, bw, 20,
                () -> Text.literal("Reset positions"), null, null,
                () -> {
                    XenomizedConfig.cfg.hudPos.clear();
                    XenomizedConfig.save();
                    clearAndInit();
                }));
        addDrawableChild(new FancyButton(width / 2 + 4, height - 30, bw, 20,
                () -> Text.literal("Done"), null, null, this::close));
    }

    private static String shortName(XenoHud.Element e) {
        return switch (e) {
            case FPS -> "FPS";
            case CPS -> "CPS";
            case COORDS -> "XYZ";
            case PING -> "Ping";
            case KEYS -> "Keys";
            case ARMOR -> "Armor";
        };
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (client.world == null) XenoBackground.draw(ctx, width, height);
        ctx.fill(0, 0, width, height, 0x55000000);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;
        String hint = "Drag a piece to move it. Tap a chip to turn it on or off.";
        ctx.drawTextWithShadow(tr, Text.literal(hint).formatted(Formatting.WHITE),
                (width - tr.getWidth(hint)) / 2, height - 70, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        XenomizedConfig.save();
        client.setScreen(parent);
    }
}
