package com.xenomized;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Decides which entities are skipped at render time. Nothing here touches the server. */
public class EntityFilter {
    private record Key(EntityType<?> type, int cx, int cy, int cz) {}

    private static final int CELL = 4; // blocks per pile cell
    private static volatile Set<Integer> hidden = Set.of();
    private static int timer = 0;

    private static int limitFor(Entity e) {
        XenomizedConfig c = XenomizedConfig.cfg;
        EntityType<?> t = e.getType();
        if (t == EntityType.ARMOR_STAND) return c.limitArmorStands;
        if (t == EntityType.TNT_MINECART) return c.limitTntMinecarts;
        if (t == EntityType.WIND_CHARGE || t == EntityType.BREEZE_WIND_CHARGE) return c.limitWindCharges;
        return 0;
    }

    /** Runs every client tick, but only scans every 10th tick. */
    public static void tick(MinecraftClient client) {
        XenomizedConfig c = XenomizedConfig.cfg;
        ClientWorld world = client.world;
        if (world == null || (c.limitArmorStands == 0 && c.limitTntMinecarts == 0 && c.limitWindCharges == 0)) {
            if (!hidden.isEmpty()) hidden = Set.of();
            return;
        }
        if (++timer % 10 != 0) return;

        Map<Key, List<Entity>> groups = new HashMap<>();
        for (Entity e : world.getEntities()) {
            if (limitFor(e) == 0) continue;
            Key k = new Key(e.getType(),
                    Math.floorDiv((int) Math.floor(e.getX()), CELL),
                    Math.floorDiv((int) Math.floor(e.getY()), CELL),
                    Math.floorDiv((int) Math.floor(e.getZ()), CELL));
            groups.computeIfAbsent(k, x -> new ArrayList<>()).add(e);
        }

        Set<Integer> out = new HashSet<>();
        for (List<Entity> list : groups.values()) {
            if (list.size() <= c.threshold) continue;
            list.sort((a, b) -> Integer.compare(a.getId(), b.getId())); // keep oldest, stable
            int keep = limitFor(list.get(0));
            for (int i = keep; i < list.size(); i++) out.add(list.get(i).getId());
        }
        hidden = out;
    }

    /** Called from the render mixin. x,y,z is the camera position. */
    public static boolean shouldHide(Entity e, double x, double y, double z) {
        if (hidden.contains(e.getId())) return true;

        XenomizedConfig c = XenomizedConfig.cfg;
        if (!c.cullEntities) return false;
        if (e instanceof PlayerEntity || e instanceof EnderDragonEntity) return false;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && e.isConnectedThroughVehicle(mc.player)) return false;

        double max = c.cullDistance;
        if (e instanceof ItemEntity && c.cullItems) max *= 0.5;
        if (e instanceof ArmorStandEntity && c.cullArmorStands) max *= 0.5;
        return e.squaredDistanceTo(x, y, z) > max * max;
    }
}
