package com.xenomized;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;

/** Xenomized, design E: pill header, numbered rows, animated background, and slide transitions when a section opens. */
public class XenomizedScreen extends Screen {
    private static final int ROW = 26;
    private static final int PAGE = 5;
    private static final String[] IDS = {"PERFORMANCE", "VISUALS", "CULLING", "LIMITS",
            "PRESETS", "HUD", "LAYOUT", "STYLE"};
    private static final String[] NAMES = {"Performance", "Visuals", "Entity culling", "Stack limits",
            "Presets", "HUD pieces", "HUD layout", "Style"};

    private static String view = "HOME";
    private static String hudGroup = "STATS";
    private static int page = 0;
    private static long animAt = 0;
    private static int animDir = 1;

    private final Screen parent;
    private final List<Shifted> shifted = new ArrayList<>();
    private int curOff = 0;

    /** A page widget that slides in or out. */
    private static final class Shifted {
        final ClickableWidget w;
        final int baseX;
        Shifted(ClickableWidget w) {
            this.w = w;
            this.baseX = w.getX();
        }
    }

    /** One numbered row on the home screen. It nudges right when hovered. */
    private static final class RowButton extends ClickableWidget {
        private final int index;
        private final String name;
        private final Runnable action;
        private float hover;

        RowButton(int x, int y, int w, int h, int index, String name, Runnable action) {
            super(x, y, w, h, Text.empty());
            this.index = index;
            this.name = name;
            this.action = action;
        }

        @Override
        protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
            hover += ((isHovered() ? 1f : 0f) - hover) * 0.25f;
            int dx = Math.round(hover * 6);
            int x = getX();
            int cy = getY() + getHeight() / 2;
            boolean lit = hover > 0.5f;
            circle(ctx, x + 16 + dx, cy, 14, lit ? Ui.accent() : 0xFF2A2E42);
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            String n = String.valueOf(index + 1);
            ctx.drawTextWithShadow(tr, Text.literal(n), x + 16 + dx - tr.getWidth(n) / 2, cy - 4, 0xFFFFFFFF);
            ctx.drawTextWithShadow(tr, Text.literal(name).formatted(Formatting.BOLD), x + 40 + dx, cy - 4, 0xFFF0F2F6);
            ctx.fill(x + 40, getY() + getHeight() - 1, x + getWidth(), getY() + getHeight(), 0x33FFFFFF);
        }

        @Override
        public void onClick(Click click, boolean doubled) {
            action.run();
        }

        @Override
        protected void appendClickableNarrations(NarrationMessageBuilder builder) {
            appendDefaultNarrations(builder);
        }
    }

    public XenomizedScreen(Screen parent) {
        super(Text.literal("Xenomized"));
        this.parent = parent;
    }

    // ---------- drawing helpers ----------
    static void circle(DrawContext ctx, int cx, int cy, int r, int col) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.sqrt(r * r - dy * dy);
            ctx.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, col);
        }
    }

    static void blob(DrawContext ctx, int cx, int cy, int r, int col) {
        for (int dy = -r; dy <= r; dy += 2) {
            int dx = (int) Math.sqrt(r * r - dy * dy);
            ctx.fill(cx - dx, cy + dy, cx + dx, cy + dy + 2, col);
        }
    }

    static void pill(DrawContext ctx, int x, int y, int w, int h, int col) {
        int r = h / 2;
        circle(ctx, x + r, y + r, r, col);
        circle(ctx, x + w - r, y + r, r, col);
        ctx.fill(x + r, y, x + w - r, y + h, col);
    }

    // ---------- helpers ----------
    private void addPage(ClickableWidget w) {
        addDrawableChild(w);
        shifted.add(new Shifted(w));
    }

    private FancyButton btn(int x, int y, int w, String label, java.util.function.Supplier<Text> value, Runnable action) {
        return new FancyButton(x, y, w, 22, () -> Text.literal(label), value, null, action);
    }

    private static Text onOff(boolean v) {
        return Text.literal(v ? "ON" : "OFF").formatted(v ? Formatting.GREEN : Formatting.RED);
    }

    private FancyButton toggle(int x, int y, int w, String label, BooleanSupplier get,
                               Consumer<Boolean> set, Runnable after) {
        return btn(x, y, w, label, () -> onOff(get.getAsBoolean()), () -> {
            set.accept(!get.getAsBoolean());
            after.run();
        });
    }

    private FancyButton cycle(int x, int y, int w, String label, int[] values, IntSupplier get,
                              IntConsumer set, IntFunction<String> fmt, Runnable after) {
        return btn(x, y, w, label,
                () -> Text.literal(fmt.apply(get.getAsInt())).formatted(Formatting.YELLOW),
                () -> {
                    int cur = get.getAsInt();
                    int idx = 0;
                    for (int i = 0; i < values.length; i++) if (values[i] == cur) idx = i;
                    set.accept(values[(idx + 1) % values.length]);
                    after.run();
                });
    }

    private static String limitText(int v) { return v == 0 ? "Off" : "Max " + v; }

    private static String titleOf(String v) {
        return switch (v) {
            case "PERFORMANCE" -> "Performance";
            case "VISUALS" -> "Visuals";
            case "CULLING" -> "Entity culling";
            case "LIMITS" -> "Stack limits";
            case "PRESETS" -> "Presets";
            case "HUD" -> "HUD pieces";
            case "HUD_LIST" -> "HUD: " + hudGroup.toLowerCase();
            case "LAYOUT" -> "HUD layout";
            case "STYLE" -> "Style";
            default -> "Choose a section";
        };
    }

    private static String descOf(String v) {
        return switch (v) {
            case "PERFORMANCE" -> "Core settings. Apply while Boost is ON.";
            case "VISUALS" -> "Cut eye candy. Apply while Boost is ON.";
            case "CULLING" -> "Hide what is behind you or far away.";
            case "LIMITS" -> "Trap spam: draw only a few per pile.";
            case "PRESETS" -> "One tap setups, from balanced to extreme.";
            case "HUD" -> "Pick a group to choose its pieces.";
            case "HUD_LIST" -> "Turn pieces on or off.";
            case "LAYOUT" -> "Move and style your HUD.";
            case "STYLE" -> "Colors, title screen, sounds and animation.";
            default -> "Tap a section to open it.";
        };
    }

    private void go(String next, int dir) {
        view = next;
        page = 0;
        animDir = dir;
        animAt = System.currentTimeMillis();
        clearAndInit();
    }

    private void back() {
        go("HUD_LIST".equals(view) ? "HUD" : "HOME", -1);
    }

    // ---------- layout ----------
    @Override
    protected void init() {
        shifted.clear();
        int cx = Math.max(20, width / 2 - 200);
        int cw = Math.min(400, width - cx * 2);

        if (!"HOME".equals(view)) {
            add(new FancyButton(14, 14, 56, 16, () -> Text.literal("< Back"), null, null, this::back));
        }
        add(new FancyButton(width - 64, 14, 50, 16, () -> Text.literal("Done"), null, null, this::close));

        if ("HOME".equals(view)) {
            int step = Math.min(46, Math.max(30, (height - 100) / 8));
            for (int i = 0; i < IDS.length; i++) {
                final int idx = i;
                final String id = IDS[i];
                addDrawableChild(new RowButton(cx, 70 + i * step, cw, step - 6, i, NAMES[i],
                        () -> go(id, 1)));
            }
            return;
        }

        XenomizedConfig c = XenomizedConfig.cfg;
        int y = 84;
        Runnable re = XenomizedConfig::reapply;
        Runnable save = XenomizedConfig::save;

        switch (view) {
            case "PERFORMANCE" -> {
                addPage(btn(cx, y, cw, "FPS Boost", () -> onOff(c.enabled), () -> {
                    c.enabled = !c.enabled;
                    if (c.enabled) XenomizedConfig.apply(); else XenomizedConfig.restore();
                })); y += ROW;
                addPage(new FancySlider(cx, y, cw, 22, "Render distance", 2, 16, 1, " chunks",
                        () -> c.renderDistance, v -> c.renderDistance = v, re)); y += ROW;
                addPage(new FancySlider(cx, y, cw, 22, "Simulation distance", 5, 16, 1, " chunks",
                        () -> c.simDistance, v -> c.simDistance = v, re)); y += ROW;
                addPage(cycle(cx, y, cw, "Max FPS", new int[]{30, 60, 120, 260}, () -> c.maxFps,
                        v -> c.maxFps = v, v -> v >= 260 ? "Unlimited" : String.valueOf(v), re)); y += ROW;
                addPage(toggle(cx, y, cw, "Fast graphics", () -> c.fastGraphics, v -> c.fastGraphics = v, re));
            }
            case "VISUALS" -> {
                addPage(toggle(cx, y, cw, "Minimal particles", () -> c.minimalParticles, v -> c.minimalParticles = v, re)); y += ROW;
                addPage(toggle(cx, y, cw, "Clouds off", () -> c.noClouds, v -> c.noClouds = v, re)); y += ROW;
                addPage(toggle(cx, y, cw, "Entity shadows off", () -> c.noShadows, v -> c.noShadows = v, re)); y += ROW;
                addPage(toggle(cx, y, cw, "Smooth lighting off", () -> c.noSmoothLighting, v -> c.noSmoothLighting = v, re)); y += ROW;
                addPage(toggle(cx, y, cw, "Biome blend off", () -> c.noBiomeBlend, v -> c.noBiomeBlend = v, re));
            }
            case "CULLING" -> {
                addPage(toggle(cx, y, cw, "Hide out of view", () -> c.cullEntities, v -> c.cullEntities = v, save)); y += ROW;
                addPage(new FancySlider(cx, y, cw, 22, "Cull distance", 16, 128, 8, " blocks",
                        () -> c.cullDistance, v -> c.cullDistance = v, save)); y += ROW;
                addPage(toggle(cx, y, cw, "Cull dropped items closer", () -> c.cullItems, v -> c.cullItems = v, save)); y += ROW;
                addPage(toggle(cx, y, cw, "Cull armor stands closer", () -> c.cullArmorStands, v -> c.cullArmorStands = v, save));
            }
            case "LIMITS" -> {
                int[] lim = {0, 1, 3};
                addPage(cycle(cx, y, cw, "Armor stands", lim, () -> c.limitArmorStands,
                        v -> c.limitArmorStands = v, XenomizedScreen::limitText, save)); y += ROW;
                addPage(cycle(cx, y, cw, "TNT minecarts", lim, () -> c.limitTntMinecarts,
                        v -> c.limitTntMinecarts = v, XenomizedScreen::limitText, save)); y += ROW;
                addPage(cycle(cx, y, cw, "Wind charges", lim, () -> c.limitWindCharges,
                        v -> c.limitWindCharges = v, XenomizedScreen::limitText, save)); y += ROW;
                addPage(cycle(cx, y, cw, "Trigger when pile is over", new int[]{5, 10, 20}, () -> c.threshold,
                        v -> c.threshold = v, v -> String.valueOf(v), save));
            }
            case "PRESETS" -> {
                addPage(btn(cx, y, cw, "Balanced", () -> Text.literal("Smooth + pretty").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetBalanced(); clearAndInit();
                })); y += ROW;
                addPage(btn(cx, y, cw, "Max FPS", () -> Text.literal("Potato mode").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetMax(); clearAndInit();
                })); y += ROW;
                addPage(btn(cx, y, cw, "Extreme", () -> Text.literal("Lowest visuals").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetExtreme(); clearAndInit();
                })); y += ROW;
                addPage(btn(cx, y, cw, "Restore my settings", () -> Text.literal("Undo all").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.resetAll(); clearAndInit();
                }));
            }
            case "HUD" -> {
                String[] groups = {"STATS", "WORLD", "PLAYER"};
                int gw = (cw - 12) / 3;
                for (int i = 0; i < groups.length; i++) {
                    String g = groups[i];
                    addPage(new FancyButton(cx + i * (gw + 6), y, gw, 56,
                            () -> Text.literal(g).formatted(Formatting.BOLD),
                            null,
                            () -> g.equals(hudGroup),
                            () -> { hudGroup = g; go("HUD_LIST", 1); }));
                }
            }
            case "HUD_LIST" -> {
                List<XenoHud.Element> items = new ArrayList<>();
                for (XenoHud.Element e : XenoHud.Element.values()) {
                    if (hudGroup.equals(XenoHud.group(e))) items.add(e);
                }
                int pages = Math.max(1, (items.size() + PAGE - 1) / PAGE);
                page = Math.floorMod(page, pages);
                int from = page * PAGE;
                int to = Math.min(items.size(), from + PAGE);
                for (int i = from; i < to; i++) {
                    XenoHud.Element e = items.get(i);
                    addPage(toggle(cx, y, cw, e.label, e::enabled, e::setEnabled, save)); y += ROW;
                }
                if (pages > 1) {
                    addPage(btn(cx, y, cw / 2 - 2, "< Prev", null, () -> { page--; clearAndInit(); }));
                    addPage(btn(cx + cw / 2 + 2, y, cw / 2 - 2, "Next >", null, () -> { page++; clearAndInit(); }));
                }
            }
            case "LAYOUT" -> {
                addPage(btn(cx, y, cw, "Edit layout", () -> Text.literal("Drag to move >").formatted(Formatting.AQUA),
                        () -> client.setScreen(new HudEditorScreen(this)))); y += ROW;
                addPage(toggle(cx, y, cw, "Background boxes", () -> c.hudBackground, v -> c.hudBackground = v, save)); y += ROW;
                addPage(btn(cx, y, cw, "Reset positions", () -> Text.literal("Default spots").formatted(Formatting.GRAY), () -> {
                    c.hudPos.clear();
                    XenomizedConfig.save();
                }));
            }
            case "STYLE" -> {
                addPage(new FancyButton(cx, y, cw, 22, () -> Text.literal("Accent color"),
                        () -> Text.literal(Ui.PALETTE_NAMES[Ui.accentIndex()]).formatted(Formatting.AQUA),
                        null, () -> {
                            c.accent = (c.accent + 1) % Ui.PALETTE.length;
                            XenomizedConfig.save();
                            clearAndInit();
                        })); y += ROW;
                addPage(toggle(cx, y, cw, "Animated background", () -> c.animBackground, v -> c.animBackground = v, save)); y += ROW;
                addPage(toggle(cx, y, cw, "Xeno title screen", () -> c.customTitle, v -> c.customTitle = v, save)); y += ROW;
                addPage(toggle(cx, y, cw, "Your image on all menus", () -> c.menuBackground, v -> c.menuBackground = v, save)); y += ROW;
                addPage(toggle(cx, y, cw, "Click sounds", () -> c.clickSound, v -> c.clickSound = v, save));
            }
            default -> { }
        }
    }

    /** Eases the page in from the side on open (or from the left on Back). */
    private void updateOffsets() {
        float p = Math.min(1f, Math.max(0f, (System.currentTimeMillis() - animAt) / 380f));
        float e = 1f - (1f - p) * (1f - p) * (1f - p);
        curOff = Math.round((1f - e) * width * 0.35f * animDir);
        for (Shifted s : shifted) s.w.setX(s.baseX + curOff);
    }

    // ---------- drawing ----------
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int top = 0xFF0A0C16;
        int bottom = 0xFF180E28;
        for (int y = 0; y < height; y += 4) {
            ctx.fill(0, y, width, y + 4, Ui.lerp(top, bottom, y / (float) height));
        }
        if (XenomizedConfig.cfg.animBackground) {
            long t = System.currentTimeMillis();
            int ax = (int) (width * 0.22f + Math.sin(t * 0.0004) * width * 0.08f);
            int ay = (int) (height * 0.32f + Math.cos(t * 0.0003) * height * 0.08f);
            blob(ctx, ax, ay, Math.max(60, height / 3), Ui.withAlpha(Ui.accent(), 0x26));
            int bx = (int) (width * 0.8f + Math.cos(t * 0.00035) * width * 0.08f);
            int by = (int) (height * 0.72f + Math.sin(t * 0.0005) * height * 0.08f);
            blob(ctx, bx, by, Math.max(60, height / 3), 0x22B060FF);
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        updateOffsets();
        super.render(ctx, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;
        int acc = Ui.accent();
        int cx = Math.max(20, width / 2 - 200);

        // pill header
        int pw = 280;
        int ph = 26;
        int px = width / 2 - pw / 2;
        pill(ctx, px, 12, pw, ph, 0xFF141826);
        String head = "XENOMIZED";
        ctx.drawTextWithShadow(tr, Text.literal(head).formatted(Formatting.BOLD),
                width / 2 - tr.getWidth(head) / 2, 21, acc);

        if ("HOME".equals(view)) {
            ctx.drawTextWithShadow(tr, Text.literal("Choose a section").formatted(Formatting.GRAY),
                    width / 2 - tr.getWidth("Choose a section") / 2, 50, 0xFFFFFFFF);
        } else {
            ctx.drawTextWithShadow(tr, Text.literal(titleOf(view)).formatted(Formatting.BOLD, Formatting.WHITE),
                    cx + curOff, 50, 0xFFFFFFFF);
            ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth(descOf(view), width - cx * 2)).formatted(Formatting.GRAY),
                    cx + curOff, 62, 0xFFFFFFFF);
        }
        if ("LIMITS".equals(view)) {
            ctx.drawTextWithShadow(tr, Text.literal("Visual only. Hitboxes and server unchanged.").formatted(Formatting.DARK_GRAY),
                    cx, height - 16, 0xFFFFFFFF);
        }
    }

    @Override
    public void close() {
        XenomizedConfig.save();
        client.setScreen(parent);
    }
}
