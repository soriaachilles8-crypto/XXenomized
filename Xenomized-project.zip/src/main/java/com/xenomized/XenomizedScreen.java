package com.xenomized;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class XenomizedScreen extends Screen {
    private static final int ACCENT = 0xFF35D0FF;
    private static final int ACCENT_DARK = 0xFF1A6E8A;
    private static final int ROW = 26;

    private enum Tab {
        PERFORMANCE("Performance", "Core settings. Apply while Boost is ON."),
        VISUALS("Visuals", "Cut eye candy. Apply while Boost is ON."),
        CULLING("Entity Culling", "Stop drawing far away entities."),
        LIMITS("Stack Limits", "Trap spam: draw only a few per pile."),
        PRESETS("Presets", "One tap setups.");

        final String title, desc;
        Tab(String title, String desc) { this.title = title; this.desc = desc; }
    }

    private static Tab current = Tab.PERFORMANCE;

    private final Screen parent;
    private int px, py, pw, ph;

    public XenomizedScreen(Screen parent) {
        super(Text.literal("Xenomized"));
        this.parent = parent;
    }

    // ---------- helpers ----------
    private void add(ClickableWidget w) { addDrawableChild(w); }

    private static Text onOff(boolean v) {
        return Text.literal(v ? "ON" : "OFF").formatted(v ? Formatting.GREEN : Formatting.RED);
    }

    private FancyButton btn(int x, int y, int w, String label, Supplier<Text> value, Runnable action) {
        return new FancyButton(x, y, w, 22, () -> Text.literal(label), value, null, action);
    }

    private FancyButton toggle(int x, int y, int w, String label, BooleanSupplier get,
                               Consumer<Boolean> set, Runnable after) {
        return btn(x, y, w, label, () -> onOff(get.getAsBoolean()), () -> {
            set.accept(!get.getAsBoolean());
            after.run();
        });
    }

    private FancyButton cycle(int x, int y, int w, String label, int[] values, IntSupplier get,
                              IntConsumer set, IntFunction<String> fmt, Runnable after) {
        return btn(x, y, w, label,
                () -> Text.literal(fmt.apply(get.getAsInt())).formatted(Formatting.YELLOW),
                () -> {
                    int cur = get.getAsInt();
                    int idx = 0;
                    for (int i = 0; i < values.length; i++) if (values[i] == cur) idx = i;
                    set.accept(values[(idx + 1) % values.length]);
                    after.run();
                });
    }

    private static String limitText(int v) { return v == 0 ? "Off" : "Max " + v; }

    // ---------- layout ----------
    @Override
    protected void init() {
        pw = Math.min(width - 12, 400);
        ph = Math.min(height - 12, 216);
        px = (width - pw) / 2;
        py = (height - ph) / 2;

        // Tabs (left column)
        int ty = py + 34;
        for (Tab t : Tab.values()) {
            add(new FancyButton(px + 6, ty, 92, 22, () -> Text.literal(t.title), null,
                    () -> current == t, () -> { current = t; clearAndInit(); }));
            ty += 25;
        }
        add(new FancyButton(px + 6, py + ph - 28, 92, 22, () -> Text.literal("Done"), null, null, this::close));

        // Content (right column)
        XenomizedConfig c = XenomizedConfig.cfg;
        int cx = px + 108;
        int cw = pw - 116;
        int y = py + 52;
        Runnable re = XenomizedConfig::reapply;
        Runnable save = XenomizedConfig::save;

        switch (current) {
            case PERFORMANCE -> {
                add(btn(cx, y, cw, "Boost", () -> onOff(c.enabled), () -> {
                    c.enabled = !c.enabled;
                    if (c.enabled) XenomizedConfig.apply(); else XenomizedConfig.restore();
                })); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Render distance", 2, 16, 1, " chunks",
                        () -> c.renderDistance, v -> c.renderDistance = v, re)); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Simulation distance", 5, 16, 1, " chunks",
                        () -> c.simDistance, v -> c.simDistance = v, re)); y += ROW;
                add(cycle(cx, y, cw, "Max FPS", new int[]{30, 60, 120, 260}, () -> c.maxFps,
                        v -> c.maxFps = v, v -> v >= 260 ? "Unlimited" : String.valueOf(v), re)); y += ROW;
                add(toggle(cx, y, cw, "Fast graphics", () -> c.fastGraphics, v -> c.fastGraphics = v, re));
            }
            case VISUALS -> {
                add(toggle(cx, y, cw, "Minimal particles", () -> c.minimalParticles, v -> c.minimalParticles = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Clouds off", () -> c.noClouds, v -> c.noClouds = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Entity shadows off", () -> c.noShadows, v -> c.noShadows = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Smooth lighting off", () -> c.noSmoothLighting, v -> c.noSmoothLighting = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Biome blend off", () -> c.noBiomeBlend, v -> c.noBiomeBlend = v, re));
            }
            case CULLING -> {
                add(toggle(cx, y, cw, "Entity culling", () -> c.cullEntities, v -> c.cullEntities = v, save)); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Cull distance", 16, 128, 8, " blocks",
                        () -> c.cullDistance, v -> c.cullDistance = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Cull dropped items closer", () -> c.cullItems, v -> c.cullItems = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Cull armor stands closer", () -> c.cullArmorStands, v -> c.cullArmorStands = v, save));
            }
            case LIMITS -> {
                int[] lim = {0, 1, 3};
                add(cycle(cx, y, cw, "Armor stands", lim, () -> c.limitArmorStands,
                        v -> c.limitArmorStands = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "TNT minecarts", lim, () -> c.limitTntMinecarts,
                        v -> c.limitTntMinecarts = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "Wind charges", lim, () -> c.limitWindCharges,
                        v -> c.limitWindCharges = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "Trigger when pile is over", new int[]{5, 10, 20}, () -> c.threshold,
                        v -> c.threshold = v, v -> String.valueOf(v), save));
            }
            case PRESETS -> {
                add(btn(cx, y, cw, "Balanced", () -> Text.literal("Smooth + pretty").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetBalanced(); clearAndInit();
                })); y += ROW;
                add(btn(cx, y, cw, "Max FPS", () -> Text.literal("Potato mode").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetMax(); clearAndInit();
                })); y += ROW;
                add(btn(cx, y, cw, "Restore my settings", () -> Text.literal("Undo all").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.resetAll(); clearAndInit();
                }));
            }
        }
    }

    // ---------- drawing ----------
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xC0080810);
        ctx.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, ACCENT_DARK);
        ctx.fill(px, py, px + pw, py + ph, 0xF0141420);
        ctx.fill(px, py, px + pw, py + 26, 0xFF1B1B2D);
        ctx.fill(px, py + 26, px + pw, py + 27, ACCENT);
        ctx.fill(px, py + 27, px + 102, py + ph, 0xFF0F0F19);
        ctx.fill(px + 102, py + 27, px + 103, py + ph, 0xFF2A2A40);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;

        ctx.drawTextWithShadow(tr, Text.literal("XENOMIZED").formatted(Formatting.BOLD, Formatting.AQUA),
                px + 10, py + 9, 0xFFFFFFFF);
        String fps = client.getCurrentFps() + " FPS";
        ctx.drawTextWithShadow(tr, Text.literal(fps).formatted(Formatting.GREEN),
                px + pw - 10 - tr.getWidth(fps), py + 9, 0xFFFFFFFF);

        int cx = px + 108;
        int maxW = pw - 116;
        ctx.drawTextWithShadow(tr, Text.literal(current.title).formatted(Formatting.BOLD, Formatting.WHITE),
                cx, py + 32, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth(current.desc, maxW)).formatted(Formatting.GRAY),
                cx, py + 42, 0xFFFFFFFF);

        if (current == Tab.LIMITS) {
            ctx.drawTextWithShadow(tr,
                    Text.literal(tr.trimToWidth("Visual only. Hitboxes and server unchanged.", maxW)).formatted(Formatting.DARK_GRAY),
                    cx, py + 52 + ROW * 4 + 4, 0xFFFFFFFF);
        }
    }

    @Override
    public void close() {
        XenomizedConfig.save();
        client.setScreen(parent);
    }
}
