package com.xenomized;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

/** Flat dark button with an optional value on the right and an accent bar when selected. */
public class FancyButton extends ClickableWidget {
    private final Supplier<Text> label;
    private final Supplier<Text> value;
    private final BooleanSupplier selected;
    private final Runnable action;

    public FancyButton(int x, int y, int w, int h, Supplier<Text> label, Supplier<Text> value,
                       BooleanSupplier selected, Runnable action) {
        super(x, y, w, h, Text.empty());
        this.label = label;
        this.value = value;
        this.selected = selected;
        this.action = action;
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        boolean sel = selected != null && selected.getAsBoolean();
        int bg = sel ? 0xFF1B5A73 : (isHovered() ? 0xFF2C2C46 : 0xFF1E1E30);
        ctx.fill(x, y, x + w, y + h, bg);
        if (sel || isHovered()) ctx.fill(x, y, x + 2, y + h, 0xFF35D0FF);

        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int ty = y + (h - 8) / 2;
        ctx.drawTextWithShadow(tr, label.get(), x + 8, ty, 0xFFFFFFFF);
        if (value != null) {
            Text v = value.get();
            ctx.drawTextWithShadow(tr, v, x + w - 8 - tr.getWidth(v), ty, 0xFFFFFFFF);
        }
    }

    @Override
    public void onClick(Click click, boolean doubled) {
        action.run();
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        appendDefaultNarrations(builder);
    }
}
