package com.xenomized;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.AccessibilityOptionsScreen;
import net.minecraft.client.gui.screen.option.LanguageOptionsScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.PlayerSkinWidget;
import net.minecraft.client.realms.gui.screen.RealmsMainScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

import java.util.function.Supplier;

/** Xeno Client main menu: your picture behind, menu on the left, your 3D skin with cosmetics in the middle, widgets on the right. */
public class XenoTitleScreen extends Screen {
    private static final String[] TIPS = {
            "Tip: open Wardrobe to try hats, halos, auras and more.",
            "Tip: drag your skin to spin it around.",
            "Tip: the HUD editor lets you drag pieces anywhere.",
            "Tip: FPS Boost can be turned off any time."
    };
    private static final int ACCENT = 0xFF35D0FF;
    private static final int GRAY = 0xFF969BA5;
    private static final int WHITE = 0xFFF0F2F6;

    private int lw;
    private int rw;
    private int skinCx;
    private int skinTop;
    private int skinW;
    private int skinH;
    private int nameY;

    public XenoTitleScreen() {
        super(Text.literal("Xeno Client"));
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    private void add(ClickableWidget w) {
        addDrawableChild(w);
    }

    private FancyButton menuButton(int x, int y, int w, int h, String label, Supplier<Text> value, Runnable action) {
        return new FancyButton(x, y, w, h, () -> Text.literal(label), value, null, action);
    }

    @Override
    protected void init() {
        lw = MathHelper.clamp(width * 26 / 100, 120, 170);
        rw = MathHelper.clamp(width * 24 / 100, 110, 160);
        int bh = height >= 240 ? 22 : 18;
        int x = 12;
        int y = 44;

        // left column: jump back in + menu
        String last = XenomizedConfig.cfg.lastServer;
        boolean has = last != null && !last.isEmpty();
        String shown = has ? textRenderer.trimToWidth(last, lw - 30) : "Open server list";
        add(new FancyButton(x, y, lw, 28,
                () -> Text.literal(shown),
                () -> Text.literal(">").formatted(Formatting.AQUA),
                null,
                () -> client.setScreen(new MultiplayerScreen(this)),
                () -> Text.literal("Jump back in").formatted(Formatting.GRAY)));
        y += 36;
        add(menuButton(x, y, lw, bh, "Singleplayer", null, () -> client.setScreen(new SelectWorldScreen(this))));
        y += bh + 4;
        add(menuButton(x, y, lw, bh, "Multiplayer", null, () -> client.setScreen(new MultiplayerScreen(this))));
        y += bh + 4;
        add(menuButton(x, y, lw, bh, "Settings",
                () -> Text.literal("Xenomized").formatted(Formatting.AQUA),
                () -> client.setScreen(new OptionsScreen(this, client.options))));
        y += bh + 4;
        add(menuButton(x, y, lw, bh, "Quit game", null, () -> client.scheduleStop()));

        // right column: HUD editor + boost switch
        int rx = width - rw - 12;
        add(new FancyButton(rx + 8, 40, 64, 14, () -> Text.literal("Edit HUD"), null, () -> true,
                () -> client.setScreen(new HudEditorScreen(this))));
        add(new FancyButton(rx + 8, 82, rw - 16, 16, () -> Text.literal("Boost"),
                () -> {
                    boolean on = XenomizedConfig.cfg.enabled;
                    return Text.literal(on ? "ON" : "OFF").formatted(on ? Formatting.GREEN : Formatting.RED);
                },
                null,
                () -> {
                    XenomizedConfig c = XenomizedConfig.cfg;
                    c.enabled = !c.enabled;
                    if (c.enabled) XenomizedConfig.apply(); else XenomizedConfig.restore();
                }));

        // centre: your real 3D skin, lowered
        int left = 12 + lw;
        int right = width - rw - 12;
        skinCx = (left + right) / 2;
        skinTop = 44;
        skinH = MathHelper.clamp(height - 170, 70, 180);
        skinW = MathHelper.clamp(right - left - 8, 60, skinH);
        PlayerSkinWidget skin = new PlayerSkinWidget(skinW, skinH, client.getLoadedEntityModels(),
                client.getSkinProvider().supplySkinTextures(client.getGameProfile(), false));
        skin.setPosition(skinCx - skinW / 2, skinTop);
        add(skin);
        nameY = skinTop + skinH + 2;
        add(new FancyButton(skinCx - 44, nameY + 14, 88, 16, () -> Text.literal("Wardrobe"), null, null,
                () -> client.setScreen(new CosmeticsScreen(this))));

        // bottom row
        String name = client.getSession().getUsername();
        int bx = 12 + Math.max(70, textRenderer.getWidth(name) + 28) + 6;
        int by = height - 24;
        String[] labels = {"Realms", "Language", "Accessibility"};
        Runnable[] actions = {
                () -> client.setScreen(new RealmsMainScreen(this)),
                () -> client.setScreen(new LanguageOptionsScreen(this, client.options, client.getLanguageManager())),
                () -> client.setScreen(new AccessibilityOptionsScreen(this, client.options))
        };
        for (int i = 0; i < labels.length; i++) {
            String l = labels[i];
            int w = textRenderer.getWidth(l) + 18;
            add(new FancyButton(bx, by, w, 18, () -> Text.literal(l), null, null, actions[i]));
            bx += w + 6;
        }
        add(new FancyButton(width - 12 - 18, by, 18, 18, () -> Text.empty(), null, null,
                () -> client.setScreen(new OptionsScreen(this, client.options))));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        XenoBackground.draw(ctx, width, height);
    }

    private void card(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h, String caption) {
        Ui.glass(ctx, x, y, w, h, false);
        ctx.drawTextWithShadow(tr, Text.literal(caption).formatted(Formatting.GRAY), x + 8, y + 5, GRAY);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;

        // cosmetics go over the skin
        Cosmetics.render(ctx, skinCx, skinTop, skinH);

        // logo
        Ui.rounded(ctx, 12, 10, 26, 26, ACCENT);
        ctx.drawTextWithShadow(tr, Text.literal("X").formatted(Formatting.BOLD, Formatting.BLACK), 22, 19, 0xFF08121A);
        ctx.drawTextWithShadow(tr, Text.literal("Xeno Client").formatted(Formatting.BOLD, Formatting.WHITE), 46, 12, WHITE);
        ctx.drawTextWithShadow(tr, Text.literal("Minecraft 1.21.11").formatted(Formatting.GRAY), 46, 25, GRAY);

        // right cards
        int rx = width - rw - 12;
        card(ctx, tr, rx, 12, rw, 46, "YOUR HUD");
        ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth("FPS, keystrokes, armor and more", rw - 16)), rx + 8, 27, GRAY);
        card(ctx, tr, rx, 64, rw, 40, "FPS BOOST");
        card(ctx, tr, rx, 110, rw, 40, "PERFORMANCE");
        int fps = client.getCurrentFps();
        String ms = String.format("%.1f", 1000f / Math.max(1, fps));
        ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth(fps + " FPS   " + ms + " ms", rw - 16)).formatted(Formatting.WHITE),
                rx + 8, 124, WHITE);
        ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth("frame time", rw - 16)).formatted(Formatting.GRAY),
                rx + 8, 136, GRAY);

        // name + rotating tip
        String name = client.getSession().getUsername();
        ctx.drawTextWithShadow(tr, Text.literal(name).formatted(Formatting.BOLD, Formatting.WHITE),
                skinCx - tr.getWidth(name) / 2, nameY, WHITE);
        int tipW = Math.max(160, (width - rw - 24) - (12 + lw + 12));
        String tip = tr.trimToWidth(TIPS[(int) ((System.currentTimeMillis() / 5000L) % TIPS.length)], tipW);
        ctx.drawTextWithShadow(tr, Text.literal(tip).formatted(Formatting.GRAY),
                skinCx - tr.getWidth(tip) / 2, nameY + 36, GRAY);

        // bottom-left account chip, bottom-right gear + version
        int chipW = Math.max(70, tr.getWidth(name) + 28);
        Ui.glass(ctx, 12, height - 24, chipW, 18, false);
        Ui.rounded(ctx, 18, height - 19, 8, 8, ACCENT);
        ctx.drawTextWithShadow(tr, Text.literal(name), 32, height - 19, WHITE);

        int gx = width - 12 - 9;
        int gy = height - 24 + 9;
        ctx.fill(gx - 3, gy - 3, gx + 3, gy + 3, 0xFFF0F2F6);
        ctx.fill(gx - 1, gy - 1, gx + 1, gy + 1, 0xFF1E1E30);
        ctx.fill(gx - 1, gy - 5, gx + 1, gy - 3, 0xFFF0F2F6);
        ctx.fill(gx - 1, gy + 3, gx + 1, gy + 5, 0xFFF0F2F6);
        ctx.fill(gx - 5, gy - 1, gx - 3, gy + 1, 0xFFF0F2F6);
        ctx.fill(gx + 3, gy - 1, gx + 5, gy + 1, 0xFFF0F2F6);

        String ver = "Xeno Client 1.0";
        ctx.drawTextWithShadow(tr, Text.literal(ver).formatted(Formatting.DARK_GRAY),
                width - 12 - 18 - 6 - tr.getWidth(ver), height - 19, GRAY);
    }
}
