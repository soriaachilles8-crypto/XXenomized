package com.xenomized;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

public class XenomizedScreen extends Screen {
    private static final int ACCENT = 0xFF35D0FF;
    private static final int ACCENT_DARK = 0xFF1A6E8A;
    private static final int ROW = 26;

    private enum Section {
        BOOST("FPS Boost"),
        HUD("HUD"),
        MENU("Menu");

        final String title;
        Section(String title) { this.title = title; }
    }

    private enum Tab {
        PERFORMANCE(Section.BOOST, "Performance", "Core settings. Apply while Boost is ON."),
        VISUALS(Section.BOOST, "Visuals", "Cut eye candy. Apply while Boost is ON."),
        CULLING(Section.BOOST, "Entity Culling", "Stop drawing far away entities."),
        LIMITS(Section.BOOST, "Stack Limits", "Trap spam: draw only a few per pile."),
        PRESETS(Section.BOOST, "Presets", "One tap setups."),
        HUD_ELEMENTS(Section.HUD, "Elements", "Choose what shows on screen."),
        HUD_LAYOUT(Section.HUD, "Layout", "Move and style your HUD."),
        MENU_SCREENS(Section.MENU, "Menus", "Title screen and menu look.");

        final Section section;
        final String title;
        final String desc;

        Tab(Section section, String title, String desc) {
            this.section = section;
            this.title = title;
            this.desc = desc;
        }
    }

    private static Tab current = Tab.PERFORMANCE;

    private final Screen parent;
    private int px, py, pw, ph;

    public XenomizedScreen(Screen parent) {
        super(Text.literal("Xenomized"));
        this.parent = parent;
    }

    // ---------- helpers ----------
    private void add(ClickableWidget w) { addDrawableChild(w); }

    private static Text onOff(boolean v) {
        return Text.literal(v ? "ON" : "OFF").formatted(v ? Formatting.GREEN : Formatting.RED);
    }

    private FancyButton btn(int x, int y, int w, String label, Supplier<Text> value, Runnable action) {
        return new FancyButton(x, y, w, 22, () -> Text.literal(label), value, null, action);
    }

    private FancyButton toggle(int x, int y, int w, String label, BooleanSupplier get,
                               Consumer<Boolean> set, Runnable after) {
        return btn(x, y, w, label, () -> onOff(get.getAsBoolean()), () -> {
            set.accept(!get.getAsBoolean());
            after.run();
        });
    }

    private FancyButton cycle(int x, int y, int w, String label, int[] values, IntSupplier get,
                              IntConsumer set, IntFunction<String> fmt, Runnable after) {
        return btn(x, y, w, label,
                () -> Text.literal(fmt.apply(get.getAsInt())).formatted(Formatting.YELLOW),
                () -> {
                    int cur = get.getAsInt();
                    int idx = 0;
                    for (int i = 0; i < values.length; i++) if (values[i] == cur) idx = i;
                    set.accept(values[(idx + 1) % values.length]);
                    after.run();
                });
    }

    private static String limitText(int v) { return v == 0 ? "Off" : "Max " + v; }

    private static Tab firstTab(Section s) {
        for (Tab t : Tab.values()) if (t.section == s) return t;
        return Tab.PERFORMANCE;
    }

    // ---------- layout ----------
    @Override
    protected void init() {
        pw = Math.min(width - 12, 400);
        ph = Math.min(height - 12, 216);
        px = (width - pw) / 2;
        py = (height - ph) / 2;

        // header: section switch + Done
        int secW = Math.max(40, Math.min(72, (pw - 84 - 62) / 3 - 3));
        int sx = px + 84;
        for (Section s : Section.values()) {
            add(new FancyButton(sx, py + 4, secW, 18, () -> Text.literal(s.title), null,
                    () -> current.section == s, () -> { current = firstTab(s); clearAndInit(); }));
            sx += secW + 3;
        }
        add(new FancyButton(px + pw - 56, py + 4, 50, 18, () -> Text.literal("Done"), null, null, this::close));

        // tabs of the current section
        int ty = py + 34;
        for (Tab t : Tab.values()) {
            if (t.section != current.section) continue;
            add(new FancyButton(px + 6, ty, 92, 22, () -> Text.literal(t.title), null,
                    () -> current == t, () -> { current = t; clearAndInit(); }));
            ty += 25;
        }

        // content
        XenomizedConfig c = XenomizedConfig.cfg;
        int cx = px + 108;
        int cw = pw - 116;
        int y = py + 52;
        Runnable re = XenomizedConfig::reapply;
        Runnable save = XenomizedConfig::save;

        switch (current) {
            case PERFORMANCE -> {
                add(btn(cx, y, cw, "FPS Boost", () -> onOff(c.enabled), () -> {
                    c.enabled = !c.enabled;
                    if (c.enabled) XenomizedConfig.apply(); else XenomizedConfig.restore();
                })); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Render distance", 2, 16, 1, " chunks",
                        () -> c.renderDistance, v -> c.renderDistance = v, re)); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Simulation distance", 5, 16, 1, " chunks",
                        () -> c.simDistance, v -> c.simDistance = v, re)); y += ROW;
                add(cycle(cx, y, cw, "Max FPS", new int[]{30, 60, 120, 260}, () -> c.maxFps,
                        v -> c.maxFps = v, v -> v >= 260 ? "Unlimited" : String.valueOf(v), re)); y += ROW;
                add(toggle(cx, y, cw, "Fast graphics", () -> c.fastGraphics, v -> c.fastGraphics = v, re));
            }
            case VISUALS -> {
                add(toggle(cx, y, cw, "Minimal particles", () -> c.minimalParticles, v -> c.minimalParticles = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Clouds off", () -> c.noClouds, v -> c.noClouds = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Entity shadows off", () -> c.noShadows, v -> c.noShadows = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Smooth lighting off", () -> c.noSmoothLighting, v -> c.noSmoothLighting = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Biome blend off", () -> c.noBiomeBlend, v -> c.noBiomeBlend = v, re));
            }
            case CULLING -> {
                add(toggle(cx, y, cw, "Entity culling", () -> c.cullEntities, v -> c.cullEntities = v, save)); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Cull distance", 16, 128, 8, " blocks",
                        () -> c.cullDistance, v -> c.cullDistance = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Cull dropped items closer", () -> c.cullItems, v -> c.cullItems = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Cull armor stands closer", () -> c.cullArmorStands, v -> c.cullArmorStands = v, save));
            }
            case LIMITS -> {
                int[] lim = {0, 1, 3};
                add(cycle(cx, y, cw, "Armor stands", lim, () -> c.limitArmorStands,
                        v -> c.limitArmorStands = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "TNT minecarts", lim, () -> c.limitTntMinecarts,
                        v -> c.limitTntMinecarts = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "Wind charges", lim, () -> c.limitWindCharges,
                        v -> c.limitWindCharges = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "Trigger when pile is over", new int[]{5, 10, 20}, () -> c.threshold,
                        v -> c.threshold = v, v -> String.valueOf(v), save));
            }
            case PRESETS -> {
                add(btn(cx, y, cw, "Balanced", () -> Text.literal("Smooth + pretty").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetBalanced(); clearAndInit();
                })); y += ROW;
                add(btn(cx, y, cw, "Max FPS", () -> Text.literal("Potato mode").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetMax(); clearAndInit();
                })); y += ROW;
                add(btn(cx, y, cw, "Restore my settings", () -> Text.literal("Undo all").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.resetAll(); clearAndInit();
                }));
            }
            case HUD_ELEMENTS -> {
                for (XenoHud.Element e : XenoHud.Element.values()) {
                    add(toggle(cx, y, cw, e.label, e::enabled, e::setEnabled, save));
                    y += ROW;
                }
            }
            case HUD_LAYOUT -> {
                add(btn(cx, y, cw, "Edit layout", () -> Text.literal("Drag to move >").formatted(Formatting.AQUA),
                        () -> client.setScreen(new HudEditorScreen(this)))); y += ROW;
                add(toggle(cx, y, cw, "Background boxes", () -> c.hudBackground, v -> c.hudBackground = v, save)); y += ROW;
                add(btn(cx, y, cw, "Reset positions", () -> Text.literal("Default spots").formatted(Formatting.GRAY), () -> {
                    c.hudPos.clear();
                    XenomizedConfig.save();
                }));
            }
            case MENU_SCREENS -> {
                add(toggle(cx, y, cw, "Xeno title screen", () -> c.customTitle, v -> c.customTitle = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Your image on all menus", () -> c.menuBackground, v -> c.menuBackground = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Click sounds", () -> c.clickSound, v -> c.clickSound = v, save)); y += ROW;
                add(btn(cx, y, cw, "Wardrobe", () -> Text.literal("Hats, halos, wings").formatted(Formatting.GRAY),
                        () -> client.setScreen(new CosmeticsScreen(this))));
            }
        }
    }

    // ---------- drawing ----------
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xC0080810);
        Ui.panel(ctx, px, py, pw, ph, 0xF0141420, ACCENT_DARK);
        ctx.fill(px + 2, py + 1, px + pw - 2, py + 26, 0xFF1B1B2D);
        ctx.fill(px + 2, py + 26, px + pw - 2, py + 27, ACCENT);
        ctx.fill(px + 2, py + 27, px + 102, py + ph - 2, 0xFF0F0F19);
        ctx.fill(px + 102, py + 27, px + 103, py + ph - 2, 0xFF2A2A40);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;

        ctx.drawTextWithShadow(tr, Text.literal("XENOMIZED").formatted(Formatting.BOLD, Formatting.AQUA),
                px + 10, py + 9, 0xFFFFFFFF);

        int cx = px + 108;
        int maxW = pw - 116;
        ctx.drawTextWithShadow(tr, Text.literal(current.title).formatted(Formatting.BOLD, Formatting.WHITE),
                cx, py + 32, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth(current.desc, maxW)).formatted(Formatting.GRAY),
                cx, py + 42, 0xFFFFFFFF);

        if (current == Tab.LIMITS) {
            ctx.drawTextWithShadow(tr,
                    Text.literal(tr.trimToWidth("Visual only. Hitboxes and server unchanged.", maxW)).formatted(Formatting.DARK_GRAY),
                    cx, py + 52 + ROW * 4 + 4, 0xFFFFFFFF);
        }
    }

    @Override
    public void close() {
        XenomizedConfig.save();
        client.setScreen(parent);
    }
}
