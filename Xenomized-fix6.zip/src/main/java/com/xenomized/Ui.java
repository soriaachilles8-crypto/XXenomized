package com.xenomized;

import net.minecraft.client.gui.DrawContext;

/** Drawing helpers: rounded panels built from non-overlapping rectangles, plus the liquid glass look. */
public final class Ui {
    private Ui() {}

    /** Rounded panel with a 1px border. */
    public static void panel(DrawContext c, int x, int y, int w, int h, int fill, int border) {
        c.fill(x + 2, y, x + w - 2, y + 1, border);
        c.fill(x + 2, y + h - 1, x + w - 2, y + h, border);
        c.fill(x, y + 2, x + 1, y + h - 2, border);
        c.fill(x + w - 1, y + 2, x + w, y + h - 2, border);
        c.fill(x + 1, y + 1, x + 2, y + 2, border);
        c.fill(x + w - 2, y + 1, x + w - 1, y + 2, border);
        c.fill(x + 1, y + h - 2, x + 2, y + h - 1, border);
        c.fill(x + w - 2, y + h - 2, x + w - 1, y + h - 1, border);
        c.fill(x + 2, y + 1, x + w - 2, y + h - 1, fill);
        c.fill(x + 1, y + 2, x + 2, y + h - 2, fill);
        c.fill(x + w - 2, y + 2, x + w - 1, y + h - 2, fill);
    }

    /** Rounded filled box with no border. */
    public static void rounded(DrawContext c, int x, int y, int w, int h, int fill) {
        c.fill(x + 1, y, x + w - 1, y + 1, fill);
        c.fill(x, y + 1, x + w, y + h - 1, fill);
        c.fill(x + 1, y + h - 1, x + w - 1, y + h, fill);
    }

    /** Liquid glass: translucent body, bright top edge, soft gloss, and a glow when hot. */
    public static void glass(DrawContext c, int x, int y, int w, int h, boolean hot) {
        if (hot) {
            c.fill(x - 2, y - 2, x + w + 2, y + h + 2, 0x1435D0FF); // soft outer glow
        }
        panel(c, x, y, w, h, hot ? 0x9A2A4A5E : 0x7A16161F, hot ? 0xDD7FE6FF : 0x66FFFFFF);
        c.fill(x + 3, y + 1, x + w - 3, y + 2, 0x66FFFFFF);                       // top highlight
        c.fill(x + 2, y + 2, x + w - 2, y + Math.min(h / 2, 6), 0x18FFFFFF);      // gloss band
    }
}
