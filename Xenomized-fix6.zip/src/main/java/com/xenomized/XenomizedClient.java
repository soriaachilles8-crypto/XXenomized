package com.xenomized;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class XenomizedClient implements ClientModInitializer {
    public static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        XenomizedConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("xenomized", "main"));

        // Keyboard users: K. Everyone else: the buttons in Settings or the Esc menu.
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xenomized.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            EntityFilter.tick(client);
            XenoHud.tick(client);
            while (openKey.wasPressed()) {
                client.setScreen(new XenomizedScreen(client.currentScreen));
            }
        });

        // HUD overlays (FPS, CPS, coordinates, ping, keystrokes, armor)
        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of("xenomized", "hud"),
                (context, tickCounter) -> XenoHud.render(context));

        // Remember the last server you joined for the title screen card.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            ServerInfo info = client.getCurrentServerEntry();
            if (info != null && info.name != null && !info.name.isEmpty()) {
                XenomizedConfig.cfg.lastServer = info.name;
                XenomizedConfig.save();
            }
        });

        // Buttons: Settings gets Xenomized, the Esc (pause) menu gets Xeno Client.
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof OptionsScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("Xenomized"),
                                        b -> client.setScreen(new XenomizedScreen(screen)))
                                .dimensions(4, 4, 84, 20).build());
            } else if (screen instanceof GameMenuScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("Xeno Client"),
                                        b -> client.setScreen(new XenomizedScreen(screen)))
                                .dimensions(w - 124, 4, 120, 20).build());
            }
        });
    }
}
