package com.xenomized;

import net.minecraft.client.gui.DrawContext;

/** Cosmetic catalog and drawing for the title screen player. Drawn with shapes, so nothing is copied from anyone. */
public final class Cosmetics {
    private Cosmetics() {}

    public static final String[] HATS = {"none", "top", "crown", "party", "cap", "horns", "headset", "bow"};
    public static final String[] HALOS = {"none", "gold", "cyan", "pink", "rainbow"};
    public static final String[] AURAS = {"none", "blue", "purple", "green", "fire"};
    public static final String[] PLUSH = {"none", "cat", "bunny", "slime", "ghost"};
    public static final String[] WINGS = {"none", "angel", "pixel", "bat"};

    public static String label(String id) {
        return switch (id) {
            case "top" -> "Top hat";
            case "crown" -> "Crown";
            case "party" -> "Party hat";
            case "cap" -> "Cap";
            case "horns" -> "Horns";
            case "headset" -> "Headset";
            case "bow" -> "Bow";
            case "gold" -> "Gold halo";
            case "cyan" -> "Cyan halo";
            case "pink" -> "Pink halo";
            case "rainbow" -> "Rainbow halo";
            case "blue" -> "Blue aura";
            case "purple" -> "Purple aura";
            case "green" -> "Green aura";
            case "fire" -> "Fire aura";
            case "cat" -> "Cat plush";
            case "bunny" -> "Bunny plush";
            case "slime" -> "Slime plush";
            case "ghost" -> "Ghost plush";
            case "angel" -> "Angel wings";
            case "pixel" -> "Pixel wings";
            case "bat" -> "Bat wings";
            default -> "None";
        };
    }

    public static String next(String[] list, String cur) {
        int idx = 0;
        for (int i = 0; i < list.length; i++) if (list[i].equals(cur)) idx = i;
        return list[(idx + 1) % list.length];
    }

    /** Draws the picked cosmetics over the title screen player. cx = centre x, top = top of the model, mh = model height. */
    public static void render(DrawContext c, int cx, int top, int mh) {
        XenomizedConfig k = XenomizedConfig.cfg;
        int s = Math.max(2, mh / 34);
        int hx = cx - 4 * s;
        int ht = top + 3 * s; // approximate head top
        if (!"none".equals(k.cosAura)) aura(c, cx, ht, s, k.cosAura);
        if (!"none".equals(k.cosWings)) wings(c, cx, ht, s, k.cosWings);
        if (!"none".equals(k.cosHalo)) halo(c, cx, ht - 10 * s, s, k.cosHalo);
        if (!"none".equals(k.cosHat)) hat(c, cx, hx, ht, s, k.cosHat);
        if (!"none".equals(k.cosPlush)) plush(c, cx, ht, s, k.cosPlush);
    }

    private static void aura(DrawContext c, int cx, int ht, int s, String id) {
        int col = switch (id) {
            case "purple" -> 0x28B060FF;
            case "green" -> 0x2860FF70;
            case "fire" -> 0x28FF8030;
            default -> 0x2835D0FF;
        };
        int x0 = cx - 8 * s, x1 = cx + 8 * s, y0 = ht - 4 * s, y1 = ht + 32 * s;
        for (int k = 1; k <= 4; k++) c.fill(x0 - k * s, y0 - k * s, x1 + k * s, y1 + k * s, col);
    }

    private static void wings(DrawContext c, int cx, int ht, int s, String id) {
        int col = switch (id) {
            case "pixel" -> 0xCC35D0FF;
            case "bat" -> 0xCC2A1A3A;
            default -> 0xCCFFFFFF;
        };
        for (int i = 0; i < 5; i++) {
            int y0 = ht + 2 * s + i * s;
            int y1 = ht + 12 * s - i * s / 2;
            c.fill(cx - 8 * s - 2 * s * (i + 1), y0, cx - 8 * s - 2 * s * i, y1, col);
            c.fill(cx + 8 * s + 2 * s * i, y0, cx + 8 * s + 2 * s * (i + 1), y1, col);
        }
    }

    private static void halo(DrawContext c, int cx, int cy, int s, String id) {
        int col = switch (id) {
            case "gold" -> 0xFFFFD84A;
            case "cyan" -> 0xFF35D0FF;
            case "pink" -> 0xFFFF6FB0;
            default -> rainbow();
        };
        int dot = Math.max(2, s / 2);
        for (int d = 0; d < 360; d += 12) {
            double a = Math.toRadians(d);
            int x = cx + (int) (7 * s * Math.cos(a));
            int y = cy + (int) (2 * s * Math.sin(a));
            c.fill(x, y, x + dot, y + dot, col);
        }
    }

    private static int rainbow() {
        double t = System.currentTimeMillis() / 400.0;
        int r = (int) (128 + 127 * Math.sin(t));
        int g = (int) (128 + 127 * Math.sin(t + 2.09));
        int b = (int) (128 + 127 * Math.sin(t + 4.18));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private static void hat(DrawContext c, int cx, int hx, int ht, int s, String id) {
        switch (id) {
            case "top" -> {
                c.fill(hx, ht - 7 * s, hx + 8 * s, ht - s, 0xFF141418);
                c.fill(hx - 2 * s, ht - s, hx + 10 * s, ht, 0xFF141418);
                c.fill(hx, ht - 2 * s, hx + 8 * s, ht - s, 0xFFB02030);
            }
            case "crown" -> {
                c.fill(hx, ht - 3 * s, hx + 8 * s, ht, 0xFFFFD84A);
                for (int i = 0; i < 3; i++) c.fill(hx + 3 * s * i, ht - 5 * s, hx + 3 * s * i + 2 * s, ht - 3 * s, 0xFFFFD84A);
            }
            case "party" -> {
                c.fill(cx - 4 * s, ht - 2 * s, cx + 4 * s, ht, 0xFFFF6FB0);
                c.fill(cx - 3 * s, ht - 4 * s, cx + 3 * s, ht - 2 * s, 0xFFFFD84A);
                c.fill(cx - 2 * s, ht - 6 * s, cx + 2 * s, ht - 4 * s, 0xFF35D0FF);
                c.fill(cx - s, ht - 8 * s, cx + s, ht - 6 * s, 0xFFFFFFFF);
            }
            case "cap" -> {
                c.fill(hx, ht - 3 * s, hx + 8 * s, ht, 0xFFD03030);
                c.fill(hx + 4 * s, ht - s, hx + 12 * s, ht + s, 0xFFD03030);
            }
            case "horns" -> {
                c.fill(hx - 2 * s, ht - 4 * s, hx, ht, 0xFFEDE3C8);
                c.fill(hx + 8 * s, ht - 4 * s, hx + 10 * s, ht, 0xFFEDE3C8);
            }
            case "headset" -> {
                c.fill(hx - s, ht - s, hx + 9 * s, ht, 0xFF333333);
                c.fill(hx - 2 * s, ht + 2 * s, hx, ht + 6 * s, 0xFF222222);
                c.fill(hx + 8 * s, ht + 2 * s, hx + 10 * s, ht + 6 * s, 0xFF222222);
            }
            case "bow" -> {
                c.fill(cx - 6 * s, ht - 5 * s, cx - s, ht - s, 0xFFFF6FB0);
                c.fill(cx + s, ht - 5 * s, cx + 6 * s, ht - s, 0xFFFF6FB0);
                c.fill(cx - s, ht - 4 * s, cx + s, ht - 2 * s, 0xFFFFFFFF);
            }
            default -> { }
        }
    }

    private static void plush(DrawContext c, int cx, int ht, int s, String id) {
        int px = cx - 16 * s;
        int py = ht + 22 * s;
        int body = switch (id) {
            case "bunny" -> 0xFFF2F2F2;
            case "slime" -> 0xFF5CD65C;
            case "ghost" -> 0xAAE8E8FF;
            default -> 0xFFE08A3A; // cat
        };
        c.fill(px - 1, py - 1, px + 4 * s + 1, py + 4 * s + 1, 0xFF000000);
        c.fill(px, py, px + 4 * s, py + 4 * s, body);
        if ("cat".equals(id)) {
            c.fill(px, py - 2 * s, px + s, py, body);
            c.fill(px + 3 * s, py - 2 * s, px + 4 * s, py, body);
        } else if ("bunny".equals(id)) {
            c.fill(px + s, py - 4 * s, px + 2 * s, py, body);
            c.fill(px + 3 * s, py - 4 * s, px + 4 * s, py, body);
        }
        int e = Math.max(1, s / 2);
        c.fill(px + s, py + s, px + s + e, py + s + e, 0xFF000000);
        c.fill(px + 3 * s - e, py + s, px + 3 * s, py + s + e, 0xFF000000);
    }
}
