package com.xenomized;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.function.Consumer;
import java.util.function.Supplier;

/** Wardrobe: pick a hat, halo, aura, plushie and wings for the title screen player. */
public class CosmeticsScreen extends Screen {
    private final Screen parent;
    private int px, py, pw, ph;

    public CosmeticsScreen(Screen parent) {
        super(Text.literal("Wardrobe"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        pw = Math.min(width - 12, 340);
        ph = Math.min(height - 12, 230);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        XenomizedConfig c = XenomizedConfig.cfg;
        int x = px + 20;
        int w = pw - 40;
        int y = py + 56;
        row(x, y, w, "Hat", Cosmetics.HATS, () -> c.cosHat, v -> c.cosHat = v); y += 26;
        row(x, y, w, "Halo", Cosmetics.HALOS, () -> c.cosHalo, v -> c.cosHalo = v); y += 26;
        row(x, y, w, "Aura", Cosmetics.AURAS, () -> c.cosAura, v -> c.cosAura = v); y += 26;
        row(x, y, w, "Plushie", Cosmetics.PLUSH, () -> c.cosPlush, v -> c.cosPlush = v); y += 26;
        row(x, y, w, "Wings", Cosmetics.WINGS, () -> c.cosWings, v -> c.cosWings = v);
        addDrawableChild(new FancyButton(px + pw / 2 - 50, py + ph - 30, 100, 20,
                () -> Text.literal("Done"), null, null, this::close));
    }

    private void row(int x, int y, int w, String category, String[] list,
                     Supplier<String> get, Consumer<String> set) {
        addDrawableChild(new FancyButton(x, y, w, 22,
                () -> Text.literal(category),
                () -> Text.literal(Cosmetics.label(get.get())).formatted(Formatting.AQUA),
                null,
                () -> {
                    set.accept(Cosmetics.next(list, get.get()));
                    XenomizedConfig.save();
                    clearAndInit();
                }));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        XenoBackground.draw(ctx, width, height);
        ctx.fill(0, 0, width, height, 0x40000000);
        Ui.glass(ctx, px, py, pw, ph, false);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;
        ctx.drawTextWithShadow(tr, Text.literal("WARDROBE").formatted(Formatting.BOLD, Formatting.AQUA),
                px + 20, py + 18, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, Text.literal("Pick your look. It shows on the title screen player.")
                .formatted(Formatting.GRAY), px + 20, py + 34, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        XenomizedConfig.save();
        client.setScreen(parent);
    }
}
