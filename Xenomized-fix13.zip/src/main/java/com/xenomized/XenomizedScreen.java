package com.xenomized;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;
import java.util.function.IntSupplier;

/** Xenomized: a tile home screen. Tap a tile to open its page, with a Back button to return. */
public class XenomizedScreen extends Screen {
    private static final int ROW = 26;
    private static final int PAGE = 5;
    private static final String[] TILE_IDS = {"PERFORMANCE", "VISUALS", "CULLING", "LIMITS",
            "PRESETS", "HUD", "LAYOUT", "STYLE"};
    private static final String[] TILE_CATS = {"BOOST", "BOOST", "BOOST", "BOOST",
            "BOOST", "TOOLS", "TOOLS", "LOOK"};

    private static String view = "HOME";
    private static String hudGroup = "STATS";
    private static int page = 0;

    private final Screen parent;
    private int px, py, pw, ph;

    public XenomizedScreen(Screen parent) {
        super(Text.literal("Xenomized"));
        this.parent = parent;
    }

    // ---------- helpers ----------
    private void add(ClickableWidget w) { addDrawableChild(w); }

    private static Text onOff(boolean v) {
        return Text.literal(v ? "ON" : "OFF").formatted(v ? Formatting.GREEN : Formatting.RED);
    }

    private FancyButton btn(int x, int y, int w, String label, java.util.function.Supplier<Text> value, Runnable action) {
        return new FancyButton(x, y, w, 22, () -> Text.literal(label), value, null, action);
    }

    private FancyButton toggle(int x, int y, int w, String label, BooleanSupplier get,
                               Consumer<Boolean> set, Runnable after) {
        return btn(x, y, w, label, () -> onOff(get.getAsBoolean()), () -> {
            set.accept(!get.getAsBoolean());
            after.run();
        });
    }

    private FancyButton cycle(int x, int y, int w, String label, int[] values, IntSupplier get,
                              IntConsumer set, IntFunction<String> fmt, Runnable after) {
        return btn(x, y, w, label,
                () -> Text.literal(fmt.apply(get.getAsInt())).formatted(Formatting.YELLOW),
                () -> {
                    int cur = get.getAsInt();
                    int idx = 0;
                    for (int i = 0; i < values.length; i++) if (values[i] == cur) idx = i;
                    set.accept(values[(idx + 1) % values.length]);
                    after.run();
                });
    }

    private static String limitText(int v) { return v == 0 ? "Off" : "Max " + v; }

    private static String titleOf(String v) {
        return switch (v) {
            case "PERFORMANCE" -> "Performance";
            case "VISUALS" -> "Visuals";
            case "CULLING" -> "Entity culling";
            case "LIMITS" -> "Stack limits";
            case "PRESETS" -> "Presets";
            case "HUD" -> "HUD pieces";
            case "HUD_LIST" -> "HUD: " + hudGroup.toLowerCase();
            case "LAYOUT" -> "HUD layout";
            case "STYLE" -> "Style";
            default -> "Choose a section";
        };
    }

    private static String descOf(String v) {
        return switch (v) {
            case "PERFORMANCE" -> "Core settings. Apply while Boost is ON.";
            case "VISUALS" -> "Cut eye candy. Apply while Boost is ON.";
            case "CULLING" -> "Hide what is behind you or far away.";
            case "LIMITS" -> "Trap spam: draw only a few per pile.";
            case "PRESETS" -> "One tap setups, from balanced to extreme.";
            case "HUD" -> "Pick a group to choose its pieces.";
            case "HUD_LIST" -> "Turn pieces on or off.";
            case "LAYOUT" -> "Move and style your HUD.";
            case "STYLE" -> "Colors, title screen, sounds and animation.";
            default -> "Tap a tile to open it.";
        };
    }

    private void go(String next) {
        view = next;
        page = 0;
        clearAndInit();
    }

    private void back() {
        go("HUD_LIST".equals(view) ? "HUD" : "HOME");
    }

    // ---------- layout ----------
    @Override
    protected void init() {
        pw = Math.min(width - 12, 360);
        ph = Math.min(height - 12, 230);
        px = (width - pw) / 2;
        py = (height - ph) / 2;

        if (!"HOME".equals(view)) {
            add(new FancyButton(px + 8, py + 4, 56, 16, () -> Text.literal("< Back"), null, null, this::back));
        }
        add(new FancyButton(px + pw - 58, py + 4, 50, 16, () -> Text.literal("Done"), null, null, this::close));

        if ("HOME".equals(view)) {
            homeTiles();
            return;
        }

        XenomizedConfig c = XenomizedConfig.cfg;
        int cx = px + 14;
        int cw = pw - 28;
        int y = py + 58;
        Runnable re = XenomizedConfig::reapply;
        Runnable save = XenomizedConfig::save;

        switch (view) {
            case "PERFORMANCE" -> {
                add(btn(cx, y, cw, "FPS Boost", () -> onOff(c.enabled), () -> {
                    c.enabled = !c.enabled;
                    if (c.enabled) XenomizedConfig.apply(); else XenomizedConfig.restore();
                })); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Render distance", 2, 16, 1, " chunks",
                        () -> c.renderDistance, v -> c.renderDistance = v, re)); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Simulation distance", 5, 16, 1, " chunks",
                        () -> c.simDistance, v -> c.simDistance = v, re)); y += ROW;
                add(cycle(cx, y, cw, "Max FPS", new int[]{30, 60, 120, 260}, () -> c.maxFps,
                        v -> c.maxFps = v, v -> v >= 260 ? "Unlimited" : String.valueOf(v), re)); y += ROW;
                add(toggle(cx, y, cw, "Fast graphics", () -> c.fastGraphics, v -> c.fastGraphics = v, re));
            }
            case "VISUALS" -> {
                add(toggle(cx, y, cw, "Minimal particles", () -> c.minimalParticles, v -> c.minimalParticles = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Clouds off", () -> c.noClouds, v -> c.noClouds = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Entity shadows off", () -> c.noShadows, v -> c.noShadows = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Smooth lighting off", () -> c.noSmoothLighting, v -> c.noSmoothLighting = v, re)); y += ROW;
                add(toggle(cx, y, cw, "Biome blend off", () -> c.noBiomeBlend, v -> c.noBiomeBlend = v, re));
            }
            case "CULLING" -> {
                add(toggle(cx, y, cw, "Hide out of view", () -> c.cullEntities, v -> c.cullEntities = v, save)); y += ROW;
                add(new FancySlider(cx, y, cw, 22, "Cull distance", 16, 128, 8, " blocks",
                        () -> c.cullDistance, v -> c.cullDistance = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Cull dropped items closer", () -> c.cullItems, v -> c.cullItems = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Cull armor stands closer", () -> c.cullArmorStands, v -> c.cullArmorStands = v, save));
            }
            case "LIMITS" -> {
                int[] lim = {0, 1, 3};
                add(cycle(cx, y, cw, "Armor stands", lim, () -> c.limitArmorStands,
                        v -> c.limitArmorStands = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "TNT minecarts", lim, () -> c.limitTntMinecarts,
                        v -> c.limitTntMinecarts = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "Wind charges", lim, () -> c.limitWindCharges,
                        v -> c.limitWindCharges = v, XenomizedScreen::limitText, save)); y += ROW;
                add(cycle(cx, y, cw, "Trigger when pile is over", new int[]{5, 10, 20}, () -> c.threshold,
                        v -> c.threshold = v, v -> String.valueOf(v), save));
            }
            case "PRESETS" -> {
                add(btn(cx, y, cw, "Balanced", () -> Text.literal("Smooth + pretty").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetBalanced(); clearAndInit();
                })); y += ROW;
                add(btn(cx, y, cw, "Max FPS", () -> Text.literal("Potato mode").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetMax(); clearAndInit();
                })); y += ROW;
                add(btn(cx, y, cw, "Extreme", () -> Text.literal("Lowest visuals").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.presetExtreme(); clearAndInit();
                })); y += ROW;
                add(btn(cx, y, cw, "Restore my settings", () -> Text.literal("Undo all").formatted(Formatting.GRAY), () -> {
                    XenomizedConfig.resetAll(); clearAndInit();
                }));
            }
            case "HUD" -> {
                String[] groups = {"STATS", "WORLD", "PLAYER"};
                int gw = (cw - 12) / 3;
                for (int i = 0; i < groups.length; i++) {
                    String g = groups[i];
                    add(new FancyButton(cx + i * (gw + 6), y, gw, 56,
                            () -> Text.literal(g).formatted(Formatting.BOLD),
                            null,
                            () -> g.equals(hudGroup),
                            () -> { hudGroup = g; go("HUD_LIST"); }));
                }
            }
            case "HUD_LIST" -> {
                List<XenoHud.Element> items = new ArrayList<>();
                for (XenoHud.Element e : XenoHud.Element.values()) {
                    if (hudGroup.equals(XenoHud.group(e))) items.add(e);
                }
                int pages = Math.max(1, (items.size() + PAGE - 1) / PAGE);
                page = Math.floorMod(page, pages);
                int from = page * PAGE;
                int to = Math.min(items.size(), from + PAGE);
                for (int i = from; i < to; i++) {
                    XenoHud.Element e = items.get(i);
                    add(toggle(cx, y, cw, e.label, e::enabled, e::setEnabled, save)); y += ROW;
                }
                if (pages > 1) {
                    add(btn(cx, y, cw / 2 - 2, "< Prev", null, () -> { page--; clearAndInit(); }));
                    add(btn(cx + cw / 2 + 2, y, cw / 2 - 2, "Next >", null, () -> { page++; clearAndInit(); }));
                }
            }
            case "LAYOUT" -> {
                add(btn(cx, y, cw, "Edit layout", () -> Text.literal("Drag to move >").formatted(Formatting.AQUA),
                        () -> client.setScreen(new HudEditorScreen(this)))); y += ROW;
                add(toggle(cx, y, cw, "Background boxes", () -> c.hudBackground, v -> c.hudBackground = v, save)); y += ROW;
                add(btn(cx, y, cw, "Reset positions", () -> Text.literal("Default spots").formatted(Formatting.GRAY), () -> {
                    c.hudPos.clear();
                    XenomizedConfig.save();
                }));
            }
            case "STYLE" -> {
                add(new FancyButton(cx, y, cw, 22, () -> Text.literal("Accent color"),
                        () -> Text.literal(Ui.PALETTE_NAMES[Ui.accentIndex()]).formatted(Formatting.AQUA),
                        null, () -> {
                            c.accent = (c.accent + 1) % Ui.PALETTE.length;
                            XenomizedConfig.save();
                            clearAndInit();
                        })); y += ROW;
                add(toggle(cx, y, cw, "Animated background", () -> c.animBackground, v -> c.animBackground = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Xeno title screen", () -> c.customTitle, v -> c.customTitle = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Your image on all menus", () -> c.menuBackground, v -> c.menuBackground = v, save)); y += ROW;
                add(toggle(cx, y, cw, "Click sounds", () -> c.clickSound, v -> c.clickSound = v, save));
            }
            default -> { }
        }
    }

    /** The home screen: eight tiles in two rows. */
    private void homeTiles() {
        int tw = (pw - 28 - 18) / 4;
        int th = (ph - 58 - 14) / 2;
        for (int i = 0; i < TILE_IDS.length; i++) {
            int tx = px + 14 + (i % 4) * (tw + 6);
            int ty = py + 58 + (i / 4) * (th + 6);
            String id = TILE_IDS[i];
            String cat = TILE_CATS[i];
            add(new FancyButton(tx, ty, tw, th,
                    () -> Text.literal(titleOf(id).toUpperCase()).formatted(Formatting.BOLD),
                    null, null,
                    () -> go(id),
                    () -> Text.literal(cat).formatted(Formatting.AQUA)));
        }
    }

    // ---------- drawing ----------
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0xC0080810);
        Ui.glass(ctx, px, py, pw, ph, false);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;
        int acc = Ui.accent();
        int violet = 0xFFB060FF;

        // header: title in the middle, animated accent line under it
        float time = System.currentTimeMillis() / 700f;
        for (int x = 14; x < pw - 14; x += 4) {
            float t = 0.5f + 0.5f * (float) Math.sin(time + x * 0.03);
            ctx.fill(px + x, py + 24, px + x + 4, py + 25, Ui.lerp(acc, violet, t));
        }
        String head = "XENOMIZED";
        ctx.drawTextWithShadow(tr, Text.literal(head).formatted(Formatting.BOLD), px + pw / 2 - tr.getWidth(head) / 2, py + 8, acc);

        ctx.drawTextWithShadow(tr, Text.literal(titleOf(view)).formatted(Formatting.BOLD, Formatting.WHITE),
                px + 14, py + 32, 0xFFFFFFFF);
        ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth(descOf(view), pw - 28)).formatted(Formatting.GRAY),
                px + 14, py + 44, 0xFFFFFFFF);

        if ("LIMITS".equals(view)) {
            ctx.drawTextWithShadow(tr,
                    Text.literal(tr.trimToWidth("Visual only. Hitboxes and server unchanged.", pw - 28)).formatted(Formatting.DARK_GRAY),
                    px + 14, py + ph - 14, 0xFFFFFFFF);
        }
    }

    @Override
    public void close() {
        XenomizedConfig.save();
        client.setScreen(parent);
    }
}
