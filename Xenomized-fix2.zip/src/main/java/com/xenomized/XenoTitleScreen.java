package com.xenomized;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.function.Supplier;

/** Xeno Client main menu: flat 2D background, menu on the left, widgets on the right. */
public class XenoTitleScreen extends Screen {
    private static final Identifier BG = Identifier.of("xenomized", "textures/gui/title_bg.png");
    private static final int BG_W = 1920;
    private static final int BG_H = 1080;

    private static final int ACCENT = 0xFF35D0FF;
    private static final int PANEL = 0xC80A0A0E;
    private static final int BORDER = 0xFF343440;
    private static final int GRAY = 0xFF969BA5;
    private static final int WHITE = 0xFFF0F2F6;

    private int lw;
    private int rw;

    public XenoTitleScreen() {
        super(Text.literal("Xeno Client"));
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false; // like the normal title screen, Esc does nothing here
    }

    private void add(ClickableWidget w) {
        addDrawableChild(w);
    }

    private FancyButton menuButton(int x, int y, int w, int h, String label, Supplier<Text> value, Runnable action) {
        return new FancyButton(x, y, w, h, () -> Text.literal(label), value, null, action);
    }

    @Override
    protected void init() {
        lw = MathHelper.clamp(width * 26 / 100, 118, 170);
        rw = MathHelper.clamp(width * 24 / 100, 108, 160);
        int bh = height >= 240 ? 22 : 18;
        int x = 12;
        int y = 46;

        // last server card (opens the server list)
        String last = XenomizedConfig.cfg.lastServer;
        boolean has = last != null && !last.isEmpty();
        String shown = has ? textRenderer.trimToWidth(last, lw - 30) : "Open server list";
        add(new FancyButton(x, y, lw, 28,
                () -> Text.literal(shown),
                () -> Text.literal(">").formatted(Formatting.AQUA),
                null,
                () -> client.setScreen(new MultiplayerScreen(this)),
                () -> Text.literal("LAST SERVER").formatted(Formatting.GRAY)));
        y += 36;

        add(menuButton(x, y, lw, bh, "Singleplayer", null,
                () -> client.setScreen(new SelectWorldScreen(this))));
        y += bh + 4;
        add(menuButton(x, y, lw, bh, "Multiplayer", null,
                () -> client.setScreen(new MultiplayerScreen(this))));
        y += bh + 4;
        add(menuButton(x, y, lw, bh, "Settings",
                () -> Text.literal("Xenomized").formatted(Formatting.AQUA),
                () -> client.setScreen(new OptionsScreen(this, client.options))));
        y += bh + 4;
        add(menuButton(x, y, lw, bh, "Quit game", null, () -> client.scheduleStop()));
    }

    // ---------- drawing ----------
    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // flat 2D picture, cover-fit to the screen shape
        float screenAspect = width / (float) height;
        float imgAspect = BG_W / (float) BG_H;
        int regionW;
        int regionH;
        float u;
        float v;
        if (screenAspect > imgAspect) {
            regionW = BG_W;
            regionH = Math.round(BG_W / screenAspect);
            u = 0f;
            v = (BG_H - regionH) / 2f;
        } else {
            regionH = BG_H;
            regionW = Math.round(BG_H * screenAspect);
            v = 0f;
            u = (BG_W - regionW) / 2f;
        }
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, BG, 0, 0, u, v, width, height,
                regionW, regionH, BG_W, BG_H);
        ctx.fill(0, 0, width, height, 0x78000000); // darken so text stays readable
    }

    private void panel(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x, y, x + w, y + h, PANEL);
        ctx.fill(x, y, x + w, y + 1, BORDER);
        ctx.fill(x, y + h - 1, x + w, y + h, BORDER);
        ctx.fill(x, y, x + 1, y + h, BORDER);
        ctx.fill(x + w - 1, y, x + w, y + h, BORDER);
    }

    private void card(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h,
                      String caption, String body, int bodyColor) {
        panel(ctx, x, y, w, h);
        ctx.drawTextWithShadow(tr, Text.literal(caption).formatted(Formatting.GRAY), x + 8, y + 6, GRAY);
        ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth(body, w - 16)), x + 8, y + 19, bodyColor);
    }

    private void block(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF000000);
        ctx.fill(x, y, x + w, y + h, color);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;

        // logo + name
        ctx.fill(12, 10, 38, 36, ACCENT);
        ctx.drawTextWithShadow(tr, Text.literal("X").formatted(Formatting.BOLD, Formatting.BLACK), 22, 19, 0xFF08121A);
        ctx.drawTextWithShadow(tr, Text.literal("Xeno Client").formatted(Formatting.BOLD, Formatting.WHITE), 46, 12, WHITE);
        ctx.drawTextWithShadow(tr, Text.literal("Minecraft 1.21.11").formatted(Formatting.GRAY), 46, 25, GRAY);

        // right column cards
        int rx = width - rw - 12;
        int fps = client.getCurrentFps();
        String ms = String.format("%.1f", 1000f / Math.max(1, fps));
        card(ctx, tr, rx, 12, rw, 34, "STATS", fps + " FPS   " + ms + " ms", WHITE);
        card(ctx, tr, rx, 52, rw, 34, "NOW PLAYING", "Spotify: coming soon", GRAY);
        card(ctx, tr, rx, 92, rw, 34, "HUD EDITOR", "Coming soon", GRAY);

        // center: flat player figure (placeholder look, real skin comes later)
        int left = 12 + lw;
        int right = width - rw - 12;
        int cx = (left + right) / 2;
        int u = Math.max(2, (int) (height * 0.5f / 32f));
        int figW = 16 * u;
        int figH = 32 * u;
        int top = Math.max(24, (height - figH) / 2 - 8);
        int fx = cx - figW / 2;
        ctx.fill(fx - u, top + figH + u, fx + figW + u, top + figH + 2 * u, 0x66000000);
        block(ctx, fx + 4 * u, top, 8 * u, 8 * u, 0xFFDEB28C);          // head
        ctx.fill(fx + 4 * u, top, fx + 12 * u, top + 2 * u, 0xFF46301F); // hair
        ctx.fill(fx + 5 * u, top + 4 * u, fx + 7 * u, top + 5 * u, 0xFFFFFFFF);   // eyes
        ctx.fill(fx + 9 * u, top + 4 * u, fx + 11 * u, top + 5 * u, 0xFFFFFFFF);
        block(ctx, fx + 4 * u, top + 8 * u, 8 * u, 12 * u, 0xFF3478DC);  // body
        block(ctx, fx, top + 8 * u, 4 * u, 12 * u, 0xFFDEB28C);          // arms
        block(ctx, fx + 12 * u, top + 8 * u, 4 * u, 12 * u, 0xFFDEB28C);
        block(ctx, fx + 4 * u, top + 20 * u, 4 * u, 12 * u, 0xFF28346E); // legs
        block(ctx, fx + 8 * u, top + 20 * u, 4 * u, 12 * u, 0xFF28346E);

        String name = client.getSession().getUsername();
        ctx.drawTextWithShadow(tr, Text.literal(name).formatted(Formatting.BOLD, Formatting.WHITE),
                cx - tr.getWidth(name) / 2, top + figH + 3 * u + 4, WHITE);

        // bottom-left account chip, bottom-right version
        int chipW = Math.max(70, tr.getWidth(name) + 28);
        panel(ctx, 12, height - 24, chipW, 18);
        ctx.fill(18, height - 19, 26, height - 11, ACCENT);
        ctx.drawTextWithShadow(tr, Text.literal(name), 32, height - 19, WHITE);
        String ver = "Xeno Client 1.0";
        ctx.drawTextWithShadow(tr, Text.literal(ver).formatted(Formatting.DARK_GRAY),
                width - 12 - tr.getWidth(ver), height - 19, GRAY);
    }
}
