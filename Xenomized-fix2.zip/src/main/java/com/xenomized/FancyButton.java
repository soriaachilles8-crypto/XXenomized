package com.xenomized;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Supplier;

/** Flat dark button with an optional value on the right, optional small caption, and an accent bar. */
public class FancyButton extends ClickableWidget {
    private final Supplier<Text> label;
    private final Supplier<Text> value;
    private final BooleanSupplier selected;
    private final Runnable action;
    private final Supplier<Text> caption;

    public FancyButton(int x, int y, int w, int h, Supplier<Text> label, Supplier<Text> value,
                       BooleanSupplier selected, Runnable action) {
        this(x, y, w, h, label, value, selected, action, null);
    }

    public FancyButton(int x, int y, int w, int h, Supplier<Text> label, Supplier<Text> value,
                       BooleanSupplier selected, Runnable action, Supplier<Text> caption) {
        super(x, y, w, h, Text.empty());
        this.label = label;
        this.value = value;
        this.selected = selected;
        this.action = action;
        this.caption = caption;
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        boolean sel = selected != null && selected.getAsBoolean();
        int bg = sel ? 0xFF1B5A73 : (isHovered() ? 0xFF2C2C46 : 0xFF1E1E30);
        ctx.fill(x, y, x + w, y + h, bg);
        if (sel || isHovered()) ctx.fill(x, y, x + 2, y + h, 0xFF35D0FF);

        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        int ty = y + (h - 8) / 2;
        if (caption != null) {
            ctx.drawTextWithShadow(tr, caption.get(), x + 8, y + 3, 0xFFFFFFFF);
            ty = y + h - 11;
        }
        ctx.drawTextWithShadow(tr, label.get(), x + 8, ty, 0xFFFFFFFF);
        if (value != null) {
            Text v = value.get();
            ctx.drawTextWithShadow(tr, v, x + w - 8 - tr.getWidth(v), ty, 0xFFFFFFFF);
        }
    }

    @Override
    public void onClick(Click click, boolean doubled) {
        action.run();
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        appendDefaultNarrations(builder);
    }
}
