package com.xenomized;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** The Xeno Client logo: a rounded accent square with a dark X. */
public final class Logo {
    private Logo() {}

    public static void draw(DrawContext c, TextRenderer tr, int x, int y, int size) {
        Ui.rounded(c, x, y, size, size, Ui.accent());
        String x2 = "X";
        c.drawTextWithShadow(tr, Text.literal(x2).formatted(Formatting.BOLD, Formatting.BLACK),
                x + size / 2 - tr.getWidth(x2) / 2, y + size / 2 - 4, 0xFF08121A);
    }
}
