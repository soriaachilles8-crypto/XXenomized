package com.xenomized;

import net.minecraft.client.gui.DrawContext;

/** Eighteen animated backgrounds for the Xenomized screen. Each is drawn with simple shapes. */
public final class Backgrounds {
    private Backgrounds() {}

    public static final String[] NAMES = {
            "Aurora", "Starfield", "Grid pulse", "Rain", "Snow", "Waves", "Bubbles", "Plasma",
            "Fire glow", "Matrix", "Orbits", "Nebula", "Pulse rings", "Sunset", "Lightning",
            "Stripes", "Fireflies", "Calm drift"
    };

    /** Heavy ones cost more FPS on a phone. */
    public static final boolean[] HEAVY = {
            false, false, false, false, false, false, false, true, false, false,
            false, true, false, false, false, false, false, false
    };

    public static int count() {
        return NAMES.length;
    }

    public static void draw(DrawContext c, int w, int h, int style) {
        float t = System.currentTimeMillis() / 1000f;
        int acc = Ui.accent();
        int vio = 0xFFB060FF;
        c.fill(0, 0, w, h, 0xFF0A0C16);

        switch (Math.floorMod(style, NAMES.length)) {
            case 0 -> { // aurora bands
                for (int y = 0; y < h; y += 3) {
                    float a = (float) (Math.sin(y * 0.02 + t * 0.8) * 0.5 + 0.5);
                    c.fill(0, y, w, y + 3, Ui.withAlpha(Ui.lerp(acc, vio, a), (int) (20 + a * 40)));
                }
            }
            case 1 -> { // starfield drifting sideways
                for (int i = 0; i < 60; i++) {
                    long s = (i + 1) * 0x9E3779B97F4A7C15L;
                    float sx = ((s >>> 8) & 0xFFFF) / 65535f, sy = ((s >>> 28) & 0xFFFF) / 65535f;
                    int x = (int) ((sx * w + t * (10 + i % 20)) % w);
                    int y = (int) (sy * h);
                    c.fill(x, y, x + 2, y + 2, Ui.withAlpha(0xFFFFFFFF, 120));
                }
            }
            case 2 -> { // grid pulse
                int a = (int) (25 + 20 * (Math.sin(t * 2) * 0.5 + 0.5));
                int off = (int) ((t * 20) % 32);
                for (int x = -off; x < w; x += 32) c.fill(x, 0, x + 1, h, Ui.withAlpha(acc, a));
                for (int y = -off; y < h; y += 32) c.fill(0, y, w, y + 1, Ui.withAlpha(acc, a));
            }
            case 3 -> { // rain streaks
                for (int i = 0; i < 80; i++) {
                    float fx = (i * 0.618f) % 1f, fy = (i * 0.327f) % 1f;
                    int x = (int) (fx * w);
                    int y = (int) (((fy * h) + t * (180 + i % 90)) % (h + 20)) - 10;
                    c.fill(x, y, x + 1, y + 10, Ui.withAlpha(acc, 70));
                }
            }
            case 4 -> { // snow
                for (int i = 0; i < 60; i++) {
                    float fx = (i * 0.618f) % 1f, fy = (i * 0.327f) % 1f;
                    int x = (int) (fx * w + Math.sin(t + i) * 10);
                    int y = (int) (((fy * h) + t * (25 + i % 15)) % h);
                    c.fill(x, y, x + 2, y + 2, 0x99FFFFFF);
                }
            }
            case 5 -> { // stacked waves
                for (int k = 0; k < 6; k++) {
                    float y0 = h * (0.2f + 0.12f * k);
                    int col = Ui.lerp(acc, vio, k / 5f);
                    for (int x = 0; x < w; x += 4) {
                        int y = (int) (y0 + Math.sin(x * 0.01 + t * (0.6 + k * 0.2)) * 18);
                        c.fill(x, y, x + 4, y + 2, Ui.withAlpha(col, 90));
                    }
                }
            }
            case 6 -> { // rising bubbles
                for (int i = 0; i < 20; i++) {
                    float fx = (i * 0.618f) % 1f, fy = (i * 0.327f) % 1f;
                    int x = (int) (fx * w + Math.sin(t + i) * 8);
                    int y = (int) (h - ((fy * h + t * (30 + i % 20)) % (h + 40)));
                    XenomizedScreen.circle(c, x, y, 4, Ui.withAlpha(acc, 70));
                }
            }
            case 7 -> { // plasma (heavy)
                for (int y = 0; y < h; y += 16) {
                    for (int x = 0; x < w; x += 16) {
                        double v = Math.sin(x * 0.02 + t) + Math.sin(y * 0.03 - t * 0.7) + Math.sin((x + y) * 0.015 + t * 0.5);
                        float a = (float) ((v + 3) / 6);
                        c.fill(x, y, x + 16, y + 16, Ui.withAlpha(Ui.lerp(acc, vio, a), 50));
                    }
                }
            }
            case 8 -> { // fire glow rising from the bottom
                float pulse = (float) (0.6 + 0.4 * Math.sin(t * 2));
                for (int y = (int) (h * 0.6f); y < h; y += 4) {
                    float f = (y - h * 0.6f) / (h * 0.4f);
                    c.fill(0, y, w, y + 4, Ui.withAlpha(0xFFFF8030, (int) (f * pulse * 120)));
                }
            }
            case 9 -> { // matrix columns (heavy-ish)
                for (int i = 0; i < 40; i++) {
                    int x = i * (w / 40);
                    float speed = 60 + (i * 37 % 80);
                    int head = (int) ((t * speed + i * 53) % (h + 80)) - 40;
                    for (int k = 0; k < 8; k++) {
                        int a = 200 - k * 24;
                        if (a > 0) c.fill(x, head - k * 8, x + 2, head - k * 8 + 6, Ui.withAlpha(0xFF60FF70, a));
                    }
                }
            }
            case 10 -> { // orbits
                int cx = w / 2, cy = h / 2;
                for (int ring = 1; ring <= 4; ring++) {
                    int rx = ring * (w / 10), ry = ring * (h / 9);
                    for (int i = 0; i < 40; i++) {
                        double a = t * 0.3 * ring + i * (Math.PI * 2 / 40);
                        int x = (int) (cx + Math.cos(a) * rx);
                        int y = (int) (cy + Math.sin(a) * ry);
                        c.fill(x, y, x + 2, y + 2, Ui.withAlpha(acc, 110));
                    }
                }
            }
            case 11 -> { // nebula blobs (heavy)
                int[] cols = {acc, vio, 0xFFFF6FB0};
                for (int i = 0; i < 3; i++) {
                    int x = (int) (w * (0.25 + 0.25 * i) + Math.sin(t * 0.3 + i) * w * 0.08);
                    int y = (int) (h * 0.5 + Math.cos(t * 0.25 + i * 2) * h * 0.12);
                    XenomizedScreen.blob(c, x, y, Math.max(60, h / 3), Ui.withAlpha(cols[i], 26));
                }
            }
            case 12 -> { // expanding pulse rings
                int cx = w / 2, cy = h / 2;
                for (int k = 0; k < 4; k++) {
                    float f = (t * 0.4f + k * 0.25f) % 1f;
                    int r = (int) (f * Math.max(w, h) * 0.6f);
                    int a = (int) ((1 - f) * 150);
                    for (int i = 0; i < 90; i++) {
                        double ang = i * (Math.PI * 2 / 90);
                        c.fill((int) (cx + Math.cos(ang) * r), (int) (cy + Math.sin(ang) * r),
                                (int) (cx + Math.cos(ang) * r) + 2, (int) (cy + Math.sin(ang) * r) + 2,
                                Ui.withAlpha(acc, a));
                    }
                }
            }
            case 13 -> { // sunset that shifts colour
                float s = (float) (Math.sin(t * 0.2) * 0.5 + 0.5);
                int top = Ui.lerp(0xFF2A0F3A, 0xFF4A1F4A, s);
                int bottom = Ui.lerp(0xFFFF7A3A, 0xFFFF4F7A, s);
                for (int y = 0; y < h; y += 4) c.fill(0, y, w, y + 4, Ui.lerp(top, bottom, y / (float) h));
            }
            case 14 -> { // lightning flashes
                long period = (long) Math.floor(t * 1.3);
                float phase = (t * 1.3f) % 1f;
                if (period % 7 == 0 && phase < 0.3f) {
                    int a = (int) ((1 - phase / 0.3f) * 90);
                    c.fill(0, 0, w, h, Ui.withAlpha(0xFFFFFFFF, a));
                    int x = (int) (w * (0.3f + 0.4f * ((period * 37) % 10) / 10f));
                    for (int y = 0; y < h; y += 12) {
                        int off = ((y / 12) % 2 == 0) ? 6 : -6;
                        c.fill(x + off, y, x + off + 3, y + 12, Ui.withAlpha(0xFFFFFFFF, a + 60));
                    }
                }
            }
            case 15 -> { // diagonal stripes scrolling
                for (int i = 0; i < 8; i++) {
                    int base = (int) ((i * 90 + t * 40) % (w + h));
                    for (int k = 0; k < h; k += 8) {
                        int x = (base + k) % w;
                        c.fill(x, k, x + 6, k + 8, Ui.withAlpha(acc, 40));
                    }
                }
            }
            case 16 -> { // fireflies
                for (int i = 0; i < 25; i++) {
                    float fx = (i * 0.618f) % 1f, fy = (i * 0.327f) % 1f;
                    int x = (int) (fx * w + Math.sin(t * 0.5 + i) * 40);
                    int y = (int) (fy * h + Math.cos(t * 0.4 + i) * 30);
                    int a = (int) (80 + 70 * (Math.sin(t * 2 + i) * 0.5 + 0.5));
                    XenomizedScreen.circle(c, x, y, 3, Ui.withAlpha(0xFFE8F080, a));
                }
            }
            default -> { // calm drift
                float s = (float) (Math.sin(t * 0.15) * 0.5 + 0.5);
                int top = Ui.lerp(0xFF0A0C16, 0xFF101C34, s);
                int bottom = Ui.lerp(0xFF180E28, 0xFF1A1030, s);
                for (int y = 0; y < h; y += 4) c.fill(0, y, w, y + 4, Ui.lerp(top, bottom, y / (float) h));
            }
        }
    }
}
