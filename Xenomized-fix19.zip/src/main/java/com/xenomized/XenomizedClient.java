package com.xenomized;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.EnumMap;
import java.util.Map;

public class XenomizedClient implements ClientModInitializer {
    public static KeyBinding openKey;
    /** One keybind per HUD piece. Set them in Options > Controls > Xenomized. */
    public static final Map<XenoHud.Element, KeyBinding> HUD_KEYS = new EnumMap<>(XenoHud.Element.class);

    @Override
    public void onInitializeClient() {
        XenomizedConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("xenomized", "main"));

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.xenomized.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, category));

        for (XenoHud.Element el : XenoHud.Element.values()) {
            KeyBinding kb = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.xenomized.hud." + el.id, InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, category));
            HUD_KEYS.put(el, kb);
        }

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            EntityFilter.tick(client);
            XenoHud.tick(client);
            while (openKey.wasPressed()) {
                client.setScreen(new XenomizedScreen(client.currentScreen));
            }
            for (Map.Entry<XenoHud.Element, KeyBinding> en : HUD_KEYS.entrySet()) {
                while (en.getValue().wasPressed()) {
                    en.getKey().setEnabled(!en.getKey().enabled());
                    XenomizedConfig.save();
                }
            }
        });

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
                Identifier.of("xenomized", "hud"),
                (context, tickCounter) -> XenoHud.render(context));

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            ServerInfo info = client.getCurrentServerEntry();
            if (info != null && info.name != null && !info.name.isEmpty()) {
                XenomizedConfig.cfg.lastServer = info.name;
                XenomizedConfig.cfg.lastServerAddress = info.address;
                XenomizedConfig.save();
            }
        });

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof OptionsScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("Xenomized"),
                                        b -> client.setScreen(new XenomizedScreen(screen)))
                                .dimensions(4, 4, 84, 20).build());
            } else if (screen instanceof GameMenuScreen) {
                int bx = w / 2 - 100;
                int by = h - 26;
                int bw = 200;
                int maxY = -1;
                for (ClickableWidget cw : Screens.getButtons(screen)) {
                    String msg = cw.getMessage().getString();
                    if ((msg.contains("Quit") || msg.contains("Disconnect") || msg.contains("Title"))
                            && cw.getY() > maxY) {
                        maxY = cw.getY();
                        bx = cw.getX();
                        bw = cw.getWidth();
                        by = cw.getY() + cw.getHeight() + 4;
                    }
                }
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("Xeno Client"),
                                        b -> client.setScreen(new XenomizedScreen(screen)))
                                .dimensions(bx, by, bw, 20).build());
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("Edit HUD"),
                                        b -> client.setScreen(new HudEditorScreen(screen)))
                                .dimensions(bx, by + 24, bw, 20).build());
            }
        });
    }
}
