package com.xenomized;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3x2fStack;

import java.util.HashMap;

/** One HUD piece in the editor. Drag the body to move it. Drag the blue corner to resize it. */
public class HudDragWidget extends ClickableWidget {
    private static final int HANDLE = 10;

    private final XenoHud.Element element;
    private final int screenW;
    private final int screenH;
    private final Runnable onChange;
    private int grabX;
    private int grabY;
    private boolean resizing;
    private double startX;
    private float startScale;

    public HudDragWidget(XenoHud.Element element, int x, int y, int w, int h,
                         int screenW, int screenH, Runnable onChange) {
        super(x, y, w, h, Text.empty());
        this.element = element;
        this.screenW = screenW;
        this.screenH = screenH;
        this.onChange = onChange;
    }

    private int boxW() {
        return Math.max(4, Math.round(XenoHud.size(element)[0] * XenoHud.scaleOf(element)));
    }

    private int boxH() {
        return Math.max(4, Math.round(XenoHud.size(element)[1] * XenoHud.scaleOf(element)));
    }

    private boolean isHandle(double mx, double my) {
        int hx = getX() + boxW();
        int hy = getY() + boxH();
        return mx >= hx - HANDLE && mx <= hx + 2 && my >= hy - HANDLE && my <= hy + 2;
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int x = getX();
        int y = getY();
        int w = boxW();
        int h = boxH();
        float k = XenoHud.scaleOf(element);
        Matrix3x2fStack m = ctx.getMatrices();
        m.pushMatrix();
        m.scale(k, k);
        XenoHud.draw(ctx, element, Math.round(x / k), Math.round(y / k));
        m.popMatrix();

        int col = (isHovered() || resizing) ? Ui.accent() : 0x99FFFFFF;
        ctx.fill(x - 1, y - 1, x + w + 1, y, col);
        ctx.fill(x - 1, y + h, x + w + 1, y + h + 1, col);
        ctx.fill(x - 1, y, x, y + h, col);
        ctx.fill(x + w, y, x + w + 1, y + h, col);
        ctx.fill(x + w - 5, y + h - 5, x + w + 1, y + h + 1, Ui.accent()); // resize handle
    }

    @Override
    public void onClick(Click click, boolean doubled) {
        if (isHandle(click.x(), click.y())) {
            resizing = true;
            startX = click.x();
            startScale = XenoHud.scaleOf(element);
        } else {
            grabX = (int) (click.x() - getX());
            grabY = (int) (click.y() - getY());
        }
    }

    @Override
    protected void onDrag(Click click, double offsetX, double offsetY) {
        if (resizing) {
            float s = MathHelper.clamp(startScale + (float) (click.x() - startX) / 120f, 0.5f, 2.0f);
            if (XenomizedConfig.cfg.hudScale == null) XenomizedConfig.cfg.hudScale = new HashMap<>();
            XenomizedConfig.cfg.hudScale.put(element.id, s);
        } else {
            setX(MathHelper.clamp((int) click.x() - grabX, 0, Math.max(0, screenW - boxW())));
            setY(MathHelper.clamp((int) click.y() - grabY, 0, Math.max(0, screenH - boxH())));
        }
    }

    @Override
    public void onRelease(Click click) {
        if (resizing) {
            resizing = false;
            XenomizedConfig.save();
            onChange.run(); // rebuild so the hit area matches the new size
        } else {
            XenoHud.setPosition(element, getX() / (float) screenW, getY() / (float) screenH);
        }
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        appendDefaultNarrations(builder);
    }
}
