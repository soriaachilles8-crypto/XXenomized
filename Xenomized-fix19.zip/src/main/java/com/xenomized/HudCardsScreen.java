package com.xenomized;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.KeybindsScreen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Edit HUD cards: filter tabs, search, a card per HUD piece with a status toggle, SIZE and KEY buttons. */
public class HudCardsScreen extends Screen {
    private static final String[] FILTERS = {"All", "Stats", "World", "Player"};
    private static final int BACKSPACE = 259;
    private static String filter = "All";
    private static String query = "";
    private static XenoHud.Element detail = null;
    private static int page = 0;

    private final Screen parent;
    private final List<XenoHud.Element> cardEls = new ArrayList<>();
    private final List<int[]> cards = new ArrayList<>();

    public HudCardsScreen(Screen parent) {
        super(Text.literal("Edit HUD"));
        this.parent = parent;
    }

    private void add(ClickableWidget w) {
        addDrawableChild(w);
    }

    private boolean matches(XenoHud.Element e) {
        boolean f = filter.equalsIgnoreCase("All") || XenoHud.group(e).equalsIgnoreCase(filter);
        boolean q = query.isEmpty() || e.label.toLowerCase().contains(query.toLowerCase());
        return f && q;
    }

    @Override
    protected void init() {
        cardEls.clear();
        cards.clear();
        if (detail != null) {
            initDetail();
            return;
        }

        add(new FancyButton(12, 12, 56, 16, () -> Text.literal("< Back"), null, null,
                () -> client.setScreen(parent)));
        add(new FancyButton(width - 62, 12, 50, 16, () -> Text.literal("Done"), null, null, this::close));

        int tabW = 56;
        int gap = 4;
        int tx = 12;
        for (String f : FILTERS) {
            add(new FancyButton(tx, 36, tabW, 18,
                    () -> Text.literal(f.toUpperCase()).formatted(Formatting.BOLD), null,
                    () -> f.equalsIgnoreCase(filter),
                    () -> { filter = f; page = 0; clearAndInit(); }));
            tx += tabW + gap;
        }

        List<XenoHud.Element> list = new ArrayList<>();
        for (XenoHud.Element e : XenoHud.Element.values()) if (matches(e)) list.add(e);

        int cols = Math.max(2, Math.min(4, (width - 24) / 150));
        int gap2 = 8;
        int cardW = (width - 24 - (cols - 1) * gap2) / cols;
        int cardH = 58;
        int top = 64;
        int rows = Math.max(1, (height - top - 30) / (cardH + gap2));
        int per = cols * rows;
        int pages = Math.max(1, (list.size() + per - 1) / per);
        page = Math.floorMod(page, pages);
        int from = page * per;
        int to = Math.min(list.size(), from + per);

        for (int i = from; i < to; i++) {
            XenoHud.Element e = list.get(i);
            int idx = i - from;
            int x = 12 + (idx % cols) * (cardW + gap2);
            int y = top + (idx / cols) * (cardH + gap2);
            cardEls.add(e);
            cards.add(new int[]{x, y, cardW, cardH});

            add(new FancyButton(x + 6, y + cardH - 20, 40, 16, () -> Text.literal("SIZE"), null, null,
                    () -> { detail = e; clearAndInit(); }));
            add(new FancyButton(x + 50, y + cardH - 20, 36, 16, () -> Text.literal("KEY"), null, null,
                    () -> client.setScreen(new KeybindsScreen(this, client.options))));
            add(new FancyButton(x + cardW - 74, y + cardH - 20, 70, 16,
                    () -> Text.literal(e.enabled() ? "Enabled" : "Disabled")
                            .formatted(e.enabled() ? Formatting.GREEN : Formatting.GRAY),
                    null, e::enabled,
                    () -> { e.setEnabled(!e.enabled()); XenomizedConfig.save(); }));
        }

        if (pages > 1) {
            add(new FancyButton(12, height - 26, 60, 18, () -> Text.literal("< Prev"), null, null,
                    () -> { page--; clearAndInit(); }));
            add(new FancyButton(width - 72, height - 26, 60, 18, () -> Text.literal("Next >"), null, null,
                    () -> { page++; clearAndInit(); }));
        }
    }

    private void initDetail() {
        XenoHud.Element e = detail;
        add(new FancyButton(12, 12, 56, 16, () -> Text.literal("< Back"), null, null,
                () -> { detail = null; clearAndInit(); }));
        add(new FancyButton(width - 62, 12, 50, 16, () -> Text.literal("Done"), null, null, this::close));

        int cx = Math.max(20, width / 2 - 160);
        int cw = Math.min(320, width - cx * 2);
        int y = 90;
        add(new FancySlider(cx, y, cw, 22, "Size", 50, 200, 10, "%",
                () -> Math.round(XenoHud.scaleOf(e) * 100),
                v -> {
                    if (XenomizedConfig.cfg.hudScale == null) XenomizedConfig.cfg.hudScale = new java.util.HashMap<>();
                    XenomizedConfig.cfg.hudScale.put(e.id, v / 100f);
                },
                XenomizedConfig::save));
        add(new FancyButton(cx, y + 30, cw, 22, () -> Text.literal(e.label),
                () -> e.enabled()
                        ? Text.literal("ON").formatted(Formatting.GREEN)
                        : Text.literal("OFF").formatted(Formatting.RED),
                e::enabled,
                () -> { e.setEnabled(!e.enabled()); XenomizedConfig.save(); }));
        add(new FancyButton(cx, y + 60, cw, 22, () -> Text.literal("Keybind (opens Controls)"), null, null,
                () -> client.setScreen(new KeybindsScreen(this, client.options))));
        add(new FancyButton(cx, y + 90, cw, 22, () -> Text.literal("Reset position"), null, null,
                () -> { XenomizedConfig.cfg.hudPos.remove(e.id); XenomizedConfig.save(); }));
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (detail == null && input.isValidChar()) {
            query += input.asString();
            page = 0;
            clearAndInit();
            return true;
        }
        return super.charTyped(input);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (detail == null && input.key() == BACKSPACE && !query.isEmpty()) {
            query = query.substring(0, query.length() - 1);
            page = 0;
            clearAndInit();
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        XenoBackground.draw(ctx, width, height);
        ctx.fill(0, 0, width, height, 0x90000000);
        for (int i = 0; i < cards.size(); i++) {
            int[] c = cards.get(i);
            Ui.glass(ctx, c[0], c[1], c[2], c[3], cardEls.get(i).enabled());
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        if (detail == null) {
            Logo.draw(ctx, textRenderer, width / 2 - 70, 10, 16);
            ctx.drawTextWithShadow(textRenderer, Text.literal("XENO CLIENT HUD").formatted(Formatting.BOLD),
                    width / 2 - 50, 14, 0xFFFFFFFF);

            // search box beside the tabs
            int sx = 12 + FILTERS.length * 60 + 6;
            int sw = width - sx - 12;
            if (sw > 40) {
                Ui.glass(ctx, sx, 36, sw, 18, !query.isEmpty());
                String shown = query.isEmpty() ? "Search" : query;
                int col = query.isEmpty() ? 0xFF8A8F9C : 0xFFFFFFFF;
                ctx.drawTextWithShadow(textRenderer, Text.literal(textRenderer.trimToWidth(shown, sw - 10)),
                        sx + 5, 41, col);
            }

            for (int i = 0; i < cardEls.size(); i++) {
                int[] c = cards.get(i);
                XenoHud.Element e = cardEls.get(i);
                ctx.drawTextWithShadow(textRenderer, Text.literal(e.label).formatted(Formatting.BOLD),
                        c[0] + 8, c[1] + 6, 0xFFFFFFFF);
                ctx.drawTextWithShadow(textRenderer, Text.literal(XenoHud.group(e)).formatted(Formatting.GRAY),
                        c[0] + 8, c[1] + 18, 0xFFFFFFFF);
            }
        } else {
            ctx.drawTextWithShadow(textRenderer, Text.literal(detail.label).formatted(Formatting.BOLD, Formatting.AQUA),
                    width / 2 - textRenderer.getWidth(detail.label) / 2, 60, 0xFFFFFFFF);
        }
    }

    @Override
    public void close() {
        detail = null;
        XenomizedConfig.save();
        client.setScreen(parent);
    }
}
