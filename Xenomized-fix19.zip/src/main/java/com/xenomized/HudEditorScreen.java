package com.xenomized;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.HashMap;

/** Edit HUD: drag each piece to move it, and drag its blue corner to resize it. */
public class HudEditorScreen extends Screen {
    private final Screen parent;

    public HudEditorScreen(Screen parent) {
        super(Text.literal("Edit HUD"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        for (XenoHud.Element e : XenoHud.Element.values()) {
            if (!e.enabled()) continue;
            int[] s = XenoHud.size(e);
            int[] p = XenoHud.position(e, width, height, s);
            float k = XenoHud.scaleOf(e);
            addDrawableChild(new HudDragWidget(e, p[0], p[1], Math.round(s[0] * k), Math.round(s[1] * k),
                    width, height, this::clearAndInit));
        }
        addDrawableChild(new FancyButton(width / 2 - 104, height - 26, 100, 20,
                () -> Text.literal("Done"), null, null, this::close));
        addDrawableChild(new FancyButton(width / 2 + 4, height - 26, 100, 20,
                () -> Text.literal("Reset all"), null, null, () -> {
                    XenomizedConfig.cfg.hudPos.clear();
                    if (XenomizedConfig.cfg.hudScale == null) XenomizedConfig.cfg.hudScale = new HashMap<>();
                    XenomizedConfig.cfg.hudScale.clear();
                    XenomizedConfig.save();
                    clearAndInit();
                }));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        String hint = "Drag to move. Drag the blue corner to resize.";
        ctx.drawTextWithShadow(textRenderer, Text.literal(hint).formatted(Formatting.WHITE),
                (width - textRenderer.getWidth(hint)) / 2, 8, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        XenomizedConfig.save();
        client.setScreen(parent);
    }
}
