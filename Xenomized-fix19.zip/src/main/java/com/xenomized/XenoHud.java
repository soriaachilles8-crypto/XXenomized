package com.xenomized;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

import java.time.LocalTime;
import java.util.ArrayDeque;
import java.util.function.Supplier;

/** HUD pieces: FPS, CPS, coordinates, ping, keystrokes, armor, plus 18 more (time, light, speed, health and more). */
public final class XenoHud {
    private XenoHud() {}

    private static final String[] MOON_NAMES = {
            "Full", "Waning gibbous", "Last quarter", "Waning crescent",
            "New", "Waxing crescent", "First quarter", "Waxing gibbous"
    };

    public enum Element {
        FPS("fps", "FPS counter", 0.01f, 0.02f, null),
        CPS("cps", "CPS counter", 0.01f, 0.09f, null),
        COORDS("coords", "Coordinates", 0.01f, 0.16f, null),
        PING("ping", "Ping", 0.01f, 0.27f, null),
        KEYS("keys", "Keystrokes", 0.01f, 0.55f, null),
        ARMOR("armor", "Armor status", 0.90f, 0.40f, null),
        TIME("time", "Time of day", 0.72f, 0.02f, XenoHud::timeText),
        DAY("day", "Day count", 0.72f, 0.08f, XenoHud::dayText),
        MOON("moon", "Moon phase", 0.72f, 0.14f, XenoHud::moonText),
        CLOCK("clock", "Real clock", 0.72f, 0.20f, XenoHud::clockText),
        LIGHT("light", "Light level", 0.72f, 0.26f, XenoHud::lightText),
        SPEED("speed", "Speed", 0.72f, 0.32f, XenoHud::speedText),
        DIRECTION("dir", "Facing", 0.72f, 0.38f, XenoHud::dirText),
        CHUNK("chunk", "Chunk position", 0.72f, 0.44f, XenoHud::chunkText),
        HEALTH("health", "Health", 0.72f, 0.50f, XenoHud::healthText),
        HUNGER("hunger", "Hunger", 0.72f, 0.56f, XenoHud::hungerText),
        MEMORY("memory", "Memory use", 0.72f, 0.62f, XenoHud::memoryText),
        WEATHER("weather", "Weather", 0.72f, 0.68f, XenoHud::weatherText),
        DIFFICULTY("difficulty", "Difficulty", 0.72f, 0.74f, XenoHud::difficultyText),
        HELD("held", "Held item", 0.72f, 0.80f, XenoHud::heldText),
        SERVER("server", "Server name", 0.87f, 0.02f, XenoHud::serverText),
        SNEAK("sneak", "Sneaking", 0.87f, 0.08f, XenoHud::sneakText),
        SPRINT("sprint", "Sprinting", 0.87f, 0.14f, XenoHud::sprintText),
        AIR("air", "Air supply", 0.87f, 0.20f, XenoHud::airText);

        public final String id;
        public final String label;
        public final float dx;
        public final float dy;
        public final Supplier<String> text;

        Element(String id, String label, float dx, float dy, Supplier<String> text) {
            this.id = id;
            this.label = label;
            this.dx = dx;
            this.dy = dy;
            this.text = text;
        }

        public boolean enabled() {
            XenomizedConfig c = XenomizedConfig.cfg;
            switch (this) {
                case FPS: return c.hudFps;
                case CPS: return c.hudCps;
                case COORDS: return c.hudCoords;
                case PING: return c.hudPing;
                case KEYS: return c.hudKeys;
                case ARMOR: return c.hudArmor;
                default: return c.hudExtra != null && Boolean.TRUE.equals(c.hudExtra.get(id));
            }
        }

        public void setEnabled(boolean on) {
            XenomizedConfig c = XenomizedConfig.cfg;
            switch (this) {
                case FPS: c.hudFps = on; break;
                case CPS: c.hudCps = on; break;
                case COORDS: c.hudCoords = on; break;
                case PING: c.hudPing = on; break;
                case KEYS: c.hudKeys = on; break;
                case ARMOR: c.hudArmor = on; break;
                default:
                    if (c.hudExtra == null) c.hudExtra = new java.util.HashMap<>();
                    c.hudExtra.put(id, on);
            }
        }
    }

    // ---------- CPS tracking (counted each client tick) ----------
    private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
    private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
    private static boolean prevLeft;
    private static boolean prevRight;

    public static void tick(MinecraftClient c) {
        long now = System.currentTimeMillis();
        boolean l = c.options.attackKey.isPressed();
        boolean r = c.options.useKey.isPressed();
        if (l && !prevLeft) LEFT.addLast(now);
        if (r && !prevRight) RIGHT.addLast(now);
        prevLeft = l;
        prevRight = r;
        while (!LEFT.isEmpty() && now - LEFT.peekFirst() > 1000) LEFT.removeFirst();
        while (!RIGHT.isEmpty() && now - RIGHT.peekFirst() > 1000) RIGHT.removeFirst();
    }

    /** The HUD group a piece belongs to: STATS, WORLD or PLAYER. */
    public static String group(Element e) {
        return switch (e) {
            case FPS, CPS, PING, MEMORY, COORDS, CLOCK, SERVER -> "STATS";
            case TIME, DAY, MOON, LIGHT, WEATHER, DIFFICULTY, CHUNK, DIRECTION -> "WORLD";
            default -> "PLAYER";
        };
    }

    /** The size of a piece: 1.0 is normal. */
    public static float scaleOf(Element e) {
        java.util.Map<String, Float> m = XenomizedConfig.cfg.hudScale;
        Float v = m == null ? null : m.get(e.id);
        return v == null ? 1f : v;
    }

    // ---------- helpers ----------
    private static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    private static ClientWorld world() { return mc().world; }

    private static boolean ready() { return mc().player != null && mc().world != null; }

    // ---------- text for the 18 new pieces ----------
    static String timeText() {
        ClientWorld w = world();
        if (w == null) return "Time -";
        long t = Math.floorMod(w.getTimeOfDay(), 24000L);
        int hours = (int) ((t / 1000 + 6) % 24);
        int mins = (int) ((t % 1000) * 60 / 1000);
        return String.format("Time %02d:%02d", hours, mins);
    }

    static String dayText() {
        ClientWorld w = world();
        return w == null ? "Day -" : "Day " + (w.getTimeOfDay() / 24000L);
    }

    static String moonText() {
        ClientWorld w = world();
        if (w == null) return "Moon -";
        return "Moon: " + MOON_NAMES[(int) ((w.getTimeOfDay() / 24000L) % 8)];
    }

    static String clockText() {
        LocalTime now = LocalTime.now();
        return String.format("Clock %02d:%02d", now.getHour(), now.getMinute());
    }

    static String lightText() {
        if (!ready()) return "Light -";
        return "Light " + world().getLightLevel(mc().player.getBlockPos());
    }

    static String speedText() {
        if (!ready()) return "Speed -";
        return String.format("Speed %.1f b/s", mc().player.getVelocity().horizontalLength() * 20.0);
    }

    static String dirText() {
        if (!ready()) return "Facing -";
        String f = mc().player.getHorizontalFacing().name();
        return "Facing " + f.substring(0, 1) + f.substring(1).toLowerCase();
    }

    static String chunkText() {
        if (!ready()) return "Chunk -";
        BlockPos bp = mc().player.getBlockPos();
        return "Chunk " + Math.floorDiv(bp.getX(), 16) + ", " + Math.floorDiv(bp.getZ(), 16);
    }

    static String healthText() {
        if (!ready()) return "Health -";
        return String.format("Health %.0f/%.0f", mc().player.getHealth(), mc().player.getMaxHealth());
    }

    static String hungerText() {
        if (!ready()) return "Hunger -";
        return "Hunger " + mc().player.getHungerManager().getFoodLevel() + "/20";
    }

    static String memoryText() {
        Runtime r = Runtime.getRuntime();
        long used = (r.totalMemory() - r.freeMemory()) / 1048576L;
        long max = r.maxMemory() / 1048576L;
        return "RAM " + used + "/" + max + " MB";
    }

    static String weatherText() {
        ClientWorld w = world();
        if (w == null) return "Weather -";
        return w.isRaining() ? "Weather: Rain" : "Weather: Clear";
    }

    static String difficultyText() {
        ClientWorld w = world();
        if (w == null) return "Difficulty -";
        return "Difficulty " + w.getDifficulty().getName();
    }

    static String heldText() {
        if (!ready()) return "Hand -";
        ItemStack st = mc().player.getMainHandStack();
        return st.isEmpty() ? "Hand: empty" : "Hand: " + st.getName().getString();
    }

    static String serverText() {
        ServerInfo info = mc().getCurrentServerEntry();
        return info == null ? "Singleplayer" : info.name;
    }

    static String sneakText() {
        if (!ready()) return "Sneak -";
        return mc().player.isSneaking() ? "Sneaking" : "Standing";
    }

    static String sprintText() {
        if (!ready()) return "Sprint -";
        return mc().player.isSprinting() ? "Sprinting" : "Walking";
    }

    static String airText() {
        if (!ready()) return "Air -";
        return "Air " + mc().player.getAir();
    }

    // ---------- original pieces ----------
    private static String fpsText() {
        return "FPS: " + mc().getCurrentFps();
    }

    private static String cpsText() {
        return "CPS: " + LEFT.size() + " | " + RIGHT.size();
    }

    private static String pingText() {
        MinecraftClient c = mc();
        if (c.player != null && c.getNetworkHandler() != null) {
            PlayerListEntry e = c.getNetworkHandler().getPlayerListEntry(c.player.getUuid());
            if (e != null) return "Ping: " + e.getLatency() + " ms";
        }
        return "Ping: -";
    }

    private static String[] coordsLines() {
        MinecraftClient c = mc();
        if (c.player == null) return new String[]{"XYZ: 0 64 0", "Facing: North"};
        String face = c.player.getHorizontalFacing().name();
        face = face.substring(0, 1) + face.substring(1).toLowerCase();
        return new String[]{
                "XYZ: " + (int) Math.floor(c.player.getX()) + " " + (int) Math.floor(c.player.getY())
                        + " " + (int) Math.floor(c.player.getZ()),
                "Facing: " + face
        };
    }

    private static final int KEY = 18;
    private static final int GAP = 2;

    // ---------- sizes and positions ----------
    public static int[] size(Element e) {
        TextRenderer tr = mc().textRenderer;
        if (e.text != null) return new int[]{tr.getWidth(e.text.get()) + 8, 14};
        return switch (e) {
            case FPS -> new int[]{tr.getWidth(fpsText()) + 8, 14};
            case CPS -> new int[]{tr.getWidth(cpsText()) + 8, 14};
            case PING -> new int[]{tr.getWidth(pingText()) + 8, 14};
            case COORDS -> {
                String[] l = coordsLines();
                yield new int[]{Math.max(tr.getWidth(l[0]), tr.getWidth(l[1])) + 8, 25};
            }
            case KEYS -> new int[]{3 * KEY + 2 * GAP, 2 * KEY + 2 * GAP + 12 + GAP + 14};
            case ARMOR -> new int[]{22 + tr.getWidth("0000") + 4, 4 * 18 + 4};
            default -> new int[]{60, 14};
        };
    }

    public static int[] position(Element e, int sw, int sh, int[] size) {
        float[] f = XenomizedConfig.cfg.hudPos.get(e.id);
        if (f == null || f.length < 2) f = new float[]{e.dx, e.dy};
        int x = MathHelper.clamp(Math.round(f[0] * sw), 0, Math.max(0, sw - size[0]));
        int y = MathHelper.clamp(Math.round(f[1] * sh), 0, Math.max(0, sh - size[1]));
        return new int[]{x, y};
    }

    public static void setPosition(Element e, float fx, float fy) {
        XenomizedConfig.cfg.hudPos.put(e.id, new float[]{fx, fy});
        XenomizedConfig.save();
    }

    // ---------- drawing ----------
    public static void render(DrawContext ctx) {
        MinecraftClient c = mc();
        if (c.player == null || c.options.hudHidden) return;
        int sw = c.getWindow().getScaledWidth();
        int sh = c.getWindow().getScaledHeight();
        for (Element e : Element.values()) {
            if (!e.enabled()) continue;
            int[] s = size(e);
            int[] p = position(e, sw, sh, s);
            float k = scaleOf(e);
            org.joml.Matrix3x2fStack m = ctx.getMatrices();
            m.pushMatrix();
            m.scale(k, k);
            draw(ctx, e, Math.round(p[0] / k), Math.round(p[1] / k));
            m.popMatrix();
        }
    }

    private static void text(DrawContext ctx, TextRenderer tr, String s, int x, int y) {
        ctx.drawTextWithShadow(tr, Text.literal(s), x, y, 0xFFFFFFFF);
    }

    public static void draw(DrawContext ctx, Element e, int x, int y) {
        MinecraftClient c = mc();
        TextRenderer tr = c.textRenderer;
        int[] s = size(e);
        if (e.text != null) {
            if (XenomizedConfig.cfg.hudBackground) Ui.rounded(ctx, x, y, s[0], s[1], 0x66000000);
            text(ctx, tr, e.text.get(), x + 4, y + 3);
            return;
        }
        if (XenomizedConfig.cfg.hudBackground && e != Element.KEYS && e != Element.ARMOR) {
            Ui.rounded(ctx, x, y, s[0], s[1], 0x66000000);
        }
        switch (e) {
            case FPS -> text(ctx, tr, fpsText(), x + 4, y + 3);
            case CPS -> text(ctx, tr, cpsText(), x + 4, y + 3);
            case PING -> text(ctx, tr, pingText(), x + 4, y + 3);
            case COORDS -> {
                String[] l = coordsLines();
                text(ctx, tr, l[0], x + 4, y + 3);
                text(ctx, tr, l[1], x + 4, y + 14);
            }
            case KEYS -> drawKeys(ctx, tr, x, y, c);
            case ARMOR -> drawArmor(ctx, tr, x, y, c);
            default -> { }
        }
    }

    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h, String label, boolean pressed) {
        Ui.rounded(ctx, x, y, w, h, pressed ? 0xCCFFFFFF : 0x80000000);
        int tx = x + (w - tr.getWidth(label)) / 2;
        int ty = y + (h - 8) / 2;
        ctx.drawTextWithShadow(tr, Text.literal(label), tx, ty, pressed ? 0xFF000000 : 0xFFFFFFFF);
    }

    private static void drawKeys(DrawContext ctx, TextRenderer tr, int x, int y, MinecraftClient c) {
        boolean live = c.player != null && c.currentScreen == null;
        key(ctx, tr, x + KEY + GAP, y, KEY, KEY, "W", live && c.options.forwardKey.isPressed());
        key(ctx, tr, x, y + KEY + GAP, KEY, KEY, "A", live && c.options.leftKey.isPressed());
        key(ctx, tr, x + KEY + GAP, y + KEY + GAP, KEY, KEY, "S", live && c.options.backKey.isPressed());
        key(ctx, tr, x + 2 * (KEY + GAP), y + KEY + GAP, KEY, KEY, "D", live && c.options.rightKey.isPressed());
        int total = 3 * KEY + 2 * GAP;
        key(ctx, tr, x, y + 2 * (KEY + GAP), total, 12, "SPACE", live && c.options.jumpKey.isPressed());
        int my = y + 2 * (KEY + GAP) + 12 + GAP;
        int mw = (total - GAP) / 2;
        key(ctx, tr, x, my, mw, 14, "LMB", live && c.options.attackKey.isPressed());
        key(ctx, tr, x + mw + GAP, my, mw, 14, "RMB", live && c.options.useKey.isPressed());
    }

    private static void drawArmor(DrawContext ctx, TextRenderer tr, int x, int y, MinecraftClient c) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        for (int i = 0; i < 4; i++) {
            int iy = y + 2 + i * 18;
            if (c.player != null) {
                ItemStack st = c.player.getEquippedStack(slots[i]);
                if (!st.isEmpty()) {
                    ctx.drawItem(st, x + 2, iy);
                    if (st.isDamageable()) {
                        int left = st.getMaxDamage() - st.getDamage();
                        float ratio = left / (float) st.getMaxDamage();
                        int col = ratio > 0.5f ? 0xFF55FF55 : (ratio > 0.2f ? 0xFFFFFF55 : 0xFFFF5555);
                        ctx.drawTextWithShadow(tr, Text.literal(String.valueOf(left)), x + 22, iy + 4, col);
                    }
                    continue;
                }
            }
            Ui.rounded(ctx, x + 2, iy, 16, 16, 0x33FFFFFF);
        }
    }
}
