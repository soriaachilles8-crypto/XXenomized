package com.xenomized;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Drag (or tap) slider with a glowing track. Taps on Zalith arrive as mouse clicks. */
public class FancySlider extends ClickableWidget {
    private final String name, suffix;
    private final int min, max, step;
    private final IntSupplier get;
    private final IntConsumer set;
    private final Runnable onDone;

    public FancySlider(int x, int y, int w, int h, String name, int min, int max, int step,
                       String suffix, IntSupplier get, IntConsumer set, Runnable onDone) {
        super(x, y, w, h, Text.literal(name));
        this.name = name; this.min = min; this.max = max; this.step = step;
        this.suffix = suffix; this.get = get; this.set = set; this.onDone = onDone;
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        ctx.fill(x, y, x + w, y + h, isHovered() ? 0xFF2C2C46 : 0xFF1E1E30);

        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        ctx.drawTextWithShadow(tr, Text.literal(name), x + 8, y + 3, 0xFFFFFFFF);
        String v = get.getAsInt() + suffix;
        ctx.drawTextWithShadow(tr, Text.literal(v).formatted(Formatting.YELLOW),
                x + w - 8 - tr.getWidth(v), y + 3, 0xFFFFFFFF);

        int tx = x + 8, tw = w - 16, ty = y + h - 5;
        ctx.fill(tx, ty, tx + tw, ty + 2, 0xFF0A0A12);
        double t = (get.getAsInt() - min) / (double) (max - min);
        int fx = tx + (int) (tw * t);
        ctx.fill(tx, ty, fx, ty + 2, 0xFF35D0FF);
        ctx.fill(fx - 2, ty - 2, fx + 2, ty + 4, 0xFFFFFFFF);
    }

    private void setFromMouse(double mouseX) {
        double t = MathHelper.clamp((mouseX - (getX() + 8)) / (double) (getWidth() - 16), 0.0, 1.0);
        int raw = min + (int) Math.round(t * (max - min));
        int v = min + Math.round((raw - min) / (float) step) * step;
        set.accept(MathHelper.clamp(v, min, max));
    }

    @Override
    public void onClick(Click click, boolean doubled) {
        setFromMouse(click.x());
    }

    @Override
    protected void onDrag(Click click, double offsetX, double offsetY) {
        setFromMouse(click.x());
    }

    @Override
    public void onRelease(Click click) {
        onDone.run();
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        appendDefaultNarrations(builder);
    }
}
