package com.xenomized;

import net.minecraft.client.gui.DrawContext;

/** Drawing helpers: rounded panels, the liquid glass look, and the accent palette. */
public final class Ui {
    private Ui() {}

    public static final int[] PALETTE = {0xFF35D0FF, 0xFFB060FF, 0xFFFF6FB0, 0xFF60FF70, 0xFFFFD84A};
    public static final String[] PALETTE_NAMES = {"Cyan", "Violet", "Pink", "Mint", "Gold"};

    public static int accentIndex() {
        return Math.floorMod(XenomizedConfig.cfg.accent, PALETTE.length);
    }

    public static int accent() {
        return PALETTE[accentIndex()];
    }

    public static int withAlpha(int col, int alpha) {
        return (alpha << 24) | (col & 0xFFFFFF);
    }

    /** Blends two ARGB colors. t = 0 gives a, t = 1 gives b. */
    public static int lerp(int a, int b, float t) {
        int aa = (a >>> 24) & 255, ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        int ra = (int) (aa + (ba - aa) * t);
        int rr = (int) (ar + (br - ar) * t);
        int rg = (int) (ag + (bg - ag) * t);
        int rb = (int) (ab + (bb - ab) * t);
        return (ra << 24) | (rr << 16) | (rg << 8) | rb;
    }

    /** Rounded panel with a 1px border. */
    public static void panel(DrawContext c, int x, int y, int w, int h, int fill, int border) {
        c.fill(x + 2, y, x + w - 2, y + 1, border);
        c.fill(x + 2, y + h - 1, x + w - 2, y + h, border);
        c.fill(x, y + 2, x + 1, y + h - 2, border);
        c.fill(x + w - 1, y + 2, x + w, y + h - 2, border);
        c.fill(x + 1, y + 1, x + 2, y + 2, border);
        c.fill(x + w - 2, y + 1, x + w - 1, y + 2, border);
        c.fill(x + 1, y + h - 2, x + 2, y + h - 1, border);
        c.fill(x + w - 2, y + h - 2, x + w - 1, y + h - 1, border);
        c.fill(x + 2, y + 1, x + w - 2, y + h - 1, fill);
        c.fill(x + 1, y + 2, x + 2, y + h - 2, fill);
        c.fill(x + w - 2, y + 2, x + w - 1, y + h - 2, fill);
    }

    /** Rounded filled box with no border. */
    public static void rounded(DrawContext c, int x, int y, int w, int h, int fill) {
        c.fill(x + 1, y, x + w - 1, y + 1, fill);
        c.fill(x, y + 1, x + w, y + h - 1, fill);
        c.fill(x + 1, y + h - 1, x + w - 1, y + h, fill);
    }

    /** Liquid glass: translucent body, bright top edge, soft gloss, and an accent glow when hot. */
    public static void glass(DrawContext c, int x, int y, int w, int h, boolean hot) {
        int acc = accent();
        if (hot) {
            c.fill(x - 2, y - 2, x + w + 2, y + h + 2, withAlpha(acc, 0x14)); // soft outer glow
        }
        panel(c, x, y, w, h, hot ? 0x9A2A4A5E : 0x7A16161F, hot ? withAlpha(acc, 0xDD) : 0x66FFFFFF);
        c.fill(x + 3, y + 1, x + w - 3, y + 2, 0x66FFFFFF);                       // top highlight
        c.fill(x + 2, y + 2, x + w - 2, y + Math.min(h / 2, 6), 0x18FFFFFF);      // gloss band
    }
}
