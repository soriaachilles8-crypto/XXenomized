package com.xenomized;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

/** Draws your picture cover-fitted to the screen, with an optional slow animation of accent stars. */
public final class XenoBackground {
    private static final Identifier BG = Identifier.of("xenomized", "textures/gui/title_bg.png");
    private static final int BG_W = 1920;
    private static final int BG_H = 1080;

    private XenoBackground() {}

    public static void draw(DrawContext ctx, int width, int height) {
        if (width <= 0 || height <= 0) return;
        float screenAspect = width / (float) height;
        float imgAspect = BG_W / (float) BG_H;
        int regionW;
        int regionH;
        float u;
        float v;
        if (screenAspect > imgAspect) {
            regionW = BG_W;
            regionH = Math.round(BG_W / screenAspect);
            u = 0f;
            v = (BG_H - regionH) / 2f;
        } else {
            regionH = BG_H;
            regionW = Math.round(BG_H * screenAspect);
            v = 0f;
            u = (BG_W - regionW) / 2f;
        }
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, BG, 0, 0, u, v, width, height,
                regionW, regionH, BG_W, BG_H);
        ctx.fill(0, 0, width, height, 0x50000000); // darken so text stays readable
        if (XenomizedConfig.cfg.animBackground) drawStars(ctx, width, height);
    }

    private static void drawStars(DrawContext ctx, int width, int height) {
        long t = System.currentTimeMillis();
        int acc = Ui.accent();
        for (int i = 0; i < 40; i++) {
            long h = (i + 1) * 0x9E3779B97F4A7C15L;
            float sx = ((h >>> 8) & 0xFFFF) / 65535f;
            float sy = ((h >>> 28) & 0xFFFF) / 65535f;
            float speed = 0.01f + ((h >>> 44) & 0xFF) / 255f * 0.05f; // pixels per millisecond
            int x = (int) ((sx * width + t * speed) % width);
            int y = (int) (sy * height);
            int a = 60 + (int) (((h >>> 52) & 0xFF) / 255f * 120);
            ctx.fill(x, y, x + 2, y + 2, Ui.withAlpha(acc, a));
        }
    }
}
