package com.xenomized.mixin;

import com.xenomized.XenomizedConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.PlayerSkinWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Keeps the title screen skin turning slowly on its own. Dragging still works and does not stop the spin. */
@Mixin(PlayerSkinWidget.class)
public abstract class PlayerSkinWidgetMixin {
    @Shadow private float yRotation;

    @Inject(method = "renderWidget", at = @At("HEAD"))
    private void xenomized$autoSpin(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (XenomizedConfig.cfg.skinAutoSpin) {
            yRotation += 0.4f;
        }
    }
}
