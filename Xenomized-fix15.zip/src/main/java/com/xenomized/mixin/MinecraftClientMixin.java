package com.xenomized.mixin;

import com.xenomized.XenoTitleScreen;
import com.xenomized.XenomizedConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen xenomized$replaceTitle(Screen screen) {
        if (screen != null && screen.getClass() == TitleScreen.class && XenomizedConfig.cfg.customTitle) {
            try {
                return new XenoTitleScreen();
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
        return screen;
    }
}
