package com.xenomized.mixin;

import com.xenomized.XenoBackground;
import com.xenomized.XenomizedConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Shadow public int width;
    @Shadow public int height;

    // Vanilla draws the spinning panorama behind menus when you're not in a world. Draw your picture instead.
    @Inject(method = "renderPanoramaBackground", at = @At("HEAD"), cancellable = true)
    private void xenomized$background(DrawContext context, float deltaTicks, CallbackInfo ci) {
        if (XenomizedConfig.cfg.menuBackground) {
            XenoBackground.draw(context, this.width, this.height);
            ci.cancel();
        }
    }
}
