package com.xenomized;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

/** One HUD element you can drag around in the editor (touch drag works too). */
public class HudDragWidget extends ClickableWidget {
    private final XenoHud.Element element;
    private final int screenW;
    private final int screenH;
    private int grabX;
    private int grabY;

    public HudDragWidget(XenoHud.Element element, int x, int y, int w, int h, int screenW, int screenH) {
        super(x, y, w, h, Text.empty());
        this.element = element;
        this.screenW = screenW;
        this.screenH = screenH;
    }

    @Override
    protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int x = getX(), y = getY(), w = getWidth(), h = getHeight();
        XenoHud.draw(ctx, element, x, y);
        int col = isHovered() ? 0xFF35D0FF : 0x9935D0FF;
        ctx.fill(x - 1, y - 1, x + w + 1, y, col);
        ctx.fill(x - 1, y + h, x + w + 1, y + h + 1, col);
        ctx.fill(x - 1, y, x, y + h, col);
        ctx.fill(x + w, y, x + w + 1, y + h, col);
    }

    @Override
    public void onClick(Click click, boolean doubled) {
        grabX = (int) (click.x() - getX());
        grabY = (int) (click.y() - getY());
    }

    @Override
    protected void onDrag(Click click, double offsetX, double offsetY) {
        int nx = MathHelper.clamp((int) click.x() - grabX, 0, Math.max(0, screenW - getWidth()));
        int ny = MathHelper.clamp((int) click.y() - grabY, 0, Math.max(0, screenH - getHeight()));
        setX(nx);
        setY(ny);
    }

    @Override
    public void onRelease(Click click) {
        XenoHud.setPosition(element, getX() / (float) screenW, getY() / (float) screenH);
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        appendDefaultNarrations(builder);
    }
}
