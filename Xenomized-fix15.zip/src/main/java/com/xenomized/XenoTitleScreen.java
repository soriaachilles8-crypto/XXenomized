package com.xenomized;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.AccessibilityOptionsScreen;
import net.minecraft.client.gui.screen.option.LanguageOptionsScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.PlayerSkinWidget;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.realms.gui.screen.RealmsMainScreen;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;

import java.util.function.Supplier;

/** Xeno Client main menu: small buttons around the middle, your big 3D skin in the centre, cards on the right. */
public class XenoTitleScreen extends Screen {
    private static final int GRAY = 0xFF969BA5;
    private static final int WHITE = 0xFFF0F2F6;

    private int lw;
    private int rw;
    private int skinCx;
    private int skinTop;
    private int skinW;
    private int skinH;
    private int nameY;
    private int chipW;
    private Supplier<SkinTextures> headSupplier;

    public XenoTitleScreen() {
        super(Text.literal("Xeno Client"));
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    private void add(ClickableWidget w) {
        if (w instanceof FancyButton fb) fb.stroked = true;
        addDrawableChild(w);
    }

    /** Small plain grayish-black button with a bold uppercase label. */
    private FancyButton menuButton(int x, int y, int w, int h, String label, Runnable action) {
        return new FancyButton(x, y, w, h,
                () -> Text.literal(label.toUpperCase()).formatted(Formatting.BOLD), null, null, action);
    }

    /** Joins the most recently played server, or opens the server list if there is none. */
    private void joinRecent() {
        XenomizedConfig c = XenomizedConfig.cfg;
        if (c.lastServerAddress == null || c.lastServerAddress.isEmpty()) {
            client.setScreen(new MultiplayerScreen(this));
            return;
        }
        ServerAddress addr = ServerAddress.parse(c.lastServerAddress);
        ServerInfo info = new ServerInfo(c.lastServer, c.lastServerAddress, ServerInfo.ServerType.OTHER);
        ConnectScreen.connect(this, client, addr, info, false, null);
    }

    @Override
    protected void init() {
        lw = MathHelper.clamp(width * 34 / 100, 200, 260);
        rw = MathHelper.clamp(width * 24 / 100, 110, 160);
        int bh = 28;
        int x = 12;
        // around the middle of the screen
        int y = height / 2 - 56;

        // recently played: one tap joins it
        XenomizedConfig cfg = XenomizedConfig.cfg;
        boolean has = cfg.lastServerAddress != null && !cfg.lastServerAddress.isEmpty();
        String pick = (cfg.lastServer != null && !cfg.lastServer.isEmpty())
                ? cfg.lastServer
                : (has ? cfg.lastServerAddress : "No recent server");
        final String shown = textRenderer.trimToWidth(pick, lw - 30);
        add(new FancyButton(x, y, lw, 40,
                () -> Text.literal(shown),
                () -> Text.literal(">").formatted(Formatting.AQUA),
                null,
                this::joinRecent,
                () -> Text.literal("RECENTLY PLAYED").formatted(Formatting.GRAY)));
        y += 46;

        add(menuButton(x, y, lw, bh, "Singleplayer", () -> client.setScreen(new SelectWorldScreen(this))));
        y += bh + 6;
        add(menuButton(x, y, lw, bh, "Multiplayer", () -> client.setScreen(new MultiplayerScreen(this))));
        y += bh + 6;
        add(menuButton(x, y, lw, bh, "Settings", () -> client.setScreen(new OptionsScreen(this, client.options))));
        y += bh + 6;
        add(menuButton(x, y, lw, bh, "Quit game", () -> client.scheduleStop()));
        y += bh + 6;
        add(menuButton(x, y, lw, bh, "Xenomized", () -> client.setScreen(new XenomizedScreen(this))));

        // right column: HUD editor + boost switch
        int rx = width - rw - 12;
        add(new FancyButton(rx + 8, 40, 64, 14, () -> Text.literal("Edit HUD"), null, () -> true,
                () -> client.setScreen(new HudEditorScreen(this))));
        add(new FancyButton(rx + 8, 82, rw - 16, 16, () -> Text.literal("Boost"),
                () -> {
                    boolean on = XenomizedConfig.cfg.enabled;
                    return Text.literal(on ? "ON" : "OFF").formatted(on ? Formatting.GREEN : Formatting.RED);
                },
                null,
                () -> {
                    XenomizedConfig c = XenomizedConfig.cfg;
                    c.enabled = !c.enabled;
                    if (c.enabled) XenomizedConfig.apply(); else XenomizedConfig.restore();
                }));

        // centre: your big 3D skin, in the middle
        int left = 12 + lw;
        int right = width - rw - 12;
        skinCx = (left + right) / 2;
        skinH = MathHelper.clamp((int) (height * 0.6f), 100, 260);
        skinTop = Math.max(8, (height - skinH) / 2 - 8);
        skinW = MathHelper.clamp(right - left - 8, 60, skinH);
        PlayerSkinWidget skin = new PlayerSkinWidget(skinW, skinH, client.getLoadedEntityModels(),
                client.getSkinProvider().supplySkinTextures(client.getGameProfile(), false));
        skin.setPosition(skinCx - skinW / 2, skinTop);
        add(skin);
        nameY = skinTop + skinH + 2;

        // bottom-left chip: head + name
        String name = client.getSession().getUsername();
        chipW = Math.max(96, textRenderer.getWidth(name) + 52);
        headSupplier = client.getSkinProvider().supplySkinTextures(client.getGameProfile(), false);

        // bottom row
        int bx = 12 + chipW + 8;
        int by = height - 24;
        String[] labels = {"Realms", "Language", "Accessibility"};
        Runnable[] actions = {
                () -> client.setScreen(new RealmsMainScreen(this)),
                () -> client.setScreen(new LanguageOptionsScreen(this, client.options, client.getLanguageManager())),
                () -> client.setScreen(new AccessibilityOptionsScreen(this, client.options))
        };
        for (int i = 0; i < labels.length; i++) {
            String l = labels[i];
            int w = textRenderer.getWidth(l) + 18;
            add(new FancyButton(bx, by, w, 18, () -> Text.literal(l.toUpperCase()), null, null, actions[i]));
            bx += w + 6;
        }
        add(new FancyButton(width - 12 - 18, by, 18, 18, () -> Text.empty(), null, null,
                () -> client.setScreen(new OptionsScreen(this, client.options))));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        XenoBackground.draw(ctx, width, height);
    }

    private void card(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h, String caption) {
        Ui.glass(ctx, x, y, w, h, false);
        ctx.drawTextWithShadow(tr, Text.literal(caption).formatted(Formatting.GRAY), x + 8, y + 5, GRAY);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;

        // title: just the name, no logo
        ctx.drawTextWithShadow(tr, Text.literal("Xeno Client").formatted(Formatting.BOLD, Formatting.WHITE), 12, 12, WHITE);
        ctx.drawTextWithShadow(tr, Text.literal("Minecraft 1.21.11").formatted(Formatting.GRAY), 12, 24, GRAY);

        // right cards
        int rx = width - rw - 12;
        card(ctx, tr, rx, 12, rw, 46, "YOUR HUD");
        ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth("FPS, keystrokes, armor and more", rw - 16)), rx + 8, 27, GRAY);
        card(ctx, tr, rx, 64, rw, 40, "FPS BOOST");
        card(ctx, tr, rx, 110, rw, 40, "PERFORMANCE");
        int fps = client.getCurrentFps();
        String ms = String.format("%.1f", 1000f / Math.max(1, fps));
        ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth(fps + " FPS   " + ms + " ms", rw - 16)).formatted(Formatting.WHITE),
                rx + 8, 124, WHITE);
        ctx.drawTextWithShadow(tr, Text.literal(tr.trimToWidth("frame time", rw - 16)).formatted(Formatting.GRAY),
                rx + 8, 136, GRAY);

        // name under the skin
        String name = client.getSession().getUsername();
        ctx.drawTextWithShadow(tr, Text.literal(name).formatted(Formatting.BOLD, Formatting.WHITE),
                skinCx - tr.getWidth(name) / 2, nameY, WHITE);

        // bottom-left chip: head + name
        Ui.glass(ctx, 12, height - 30, chipW, 24, false);
        PlayerSkinDrawer.draw(ctx, headSupplier.get(), 16, height - 27, 18);
        ctx.drawTextWithShadow(tr, Text.literal(name), 42, height - 23, WHITE);

        // gear + version
        int gx = width - 12 - 9;
        int gy = height - 24 + 9;
        ctx.fill(gx - 3, gy - 3, gx + 3, gy + 3, 0xFFF0F2F6);
        ctx.fill(gx - 1, gy - 1, gx + 1, gy + 1, 0xFF1E1E30);
        ctx.fill(gx - 1, gy - 5, gx + 1, gy - 3, 0xFFF0F2F6);
        ctx.fill(gx - 1, gy + 3, gx + 1, gy + 5, 0xFFF0F2F6);
        ctx.fill(gx - 5, gy - 1, gx - 3, gy + 1, 0xFFF0F2F6);
        ctx.fill(gx + 3, gy - 1, gx + 5, gy + 1, 0xFFF0F2F6);

        String ver = "Xeno Client 1.0";
        ctx.drawTextWithShadow(tr, Text.literal(ver).formatted(Formatting.DARK_GRAY),
                width - 12 - 18 - 6 - tr.getWidth(ver), height - 19, GRAY);
    }
}
