package com.xenomized;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

/** Edit HUD: filter tabs, one card per HUD piece with an on/off chip and a size button, and a per-piece page. */
public class HudCardsScreen extends Screen {
    private static final String[] FILTERS = {"All", "Stats", "World", "Player"};
    private static String filter = "All";
    private static XenoHud.Element detail = null;
    private static int page = 0;

    private final Screen parent;

    public HudCardsScreen(Screen parent) {
        super(Text.literal("Edit HUD"));
        this.parent = parent;
    }

    private void add(ClickableWidget w) {
        addDrawableChild(w);
    }

    private List<XenoHud.Element> visible() {
        List<XenoHud.Element> out = new ArrayList<>();
        for (XenoHud.Element e : XenoHud.Element.values()) {
            if (filter.equalsIgnoreCase("All") || XenoHud.group(e).equalsIgnoreCase(filter)) out.add(e);
        }
        return out;
    }

    @Override
    protected void init() {
        if (detail != null) {
            initDetail();
            return;
        }

        add(new FancyButton(12, 12, 56, 16, () -> Text.literal("< Back"), null, null,
                () -> client.setScreen(parent)));
        add(new FancyButton(width - 62, 12, 50, 16, () -> Text.literal("Done"), null, null, this::close));

        // filter tabs
        int tabW = 66;
        int gap = 6;
        int tx = width / 2 - (FILTERS.length * tabW + (FILTERS.length - 1) * gap) / 2;
        for (String f : FILTERS) {
            add(new FancyButton(tx, 36, tabW, 18,
                    () -> Text.literal(f.toUpperCase()).formatted(Formatting.BOLD), null,
                    () -> f.equalsIgnoreCase(filter),
                    () -> { filter = f; page = 0; clearAndInit(); }));
            tx += tabW + gap;
        }

        // cards
        List<XenoHud.Element> list = visible();
        int cols = Math.max(2, Math.min(4, (width - 24) / 150));
        int gap2 = 8;
        int cardW = (width - 24 - (cols - 1) * gap2) / cols;
        int cardH = 46;
        int top = 64;
        int rows = Math.max(1, (height - top - 34) / (cardH + gap2));
        int per = cols * rows;
        int pages = Math.max(1, (list.size() + per - 1) / per);
        page = Math.floorMod(page, pages);
        int from = page * per;
        int to = Math.min(list.size(), from + per);
        for (int i = from; i < to; i++) {
            XenoHud.Element e = list.get(i);
            int idx = i - from;
            int x = 12 + (idx % cols) * (cardW + gap2);
            int y = top + (idx / cols) * (cardH + gap2);
            add(new FancyButton(x, y, cardW, cardH,
                    () -> Text.literal(e.label),
                    () -> e.enabled()
                            ? Text.literal("ON").formatted(Formatting.GREEN)
                            : Text.literal("OFF").formatted(Formatting.RED),
                    e::enabled,
                    () -> { e.setEnabled(!e.enabled()); XenomizedConfig.save(); },
                    () -> Text.literal(XenoHud.group(e)).formatted(Formatting.GRAY)));
            add(new FancyButton(x + cardW - 36, y + 3, 32, 12,
                    () -> Text.literal("SIZE"), null, null,
                    () -> { detail = e; clearAndInit(); }));
        }

        if (pages > 1) {
            add(new FancyButton(12, height - 26, 60, 18, () -> Text.literal("< Prev"), null, null,
                    () -> { page--; clearAndInit(); }));
            add(new FancyButton(width - 72, height - 26, 60, 18, () -> Text.literal("Next >"), null, null,
                    () -> { page++; clearAndInit(); }));
        }
    }

    private void initDetail() {
        XenoHud.Element e = detail;
        add(new FancyButton(12, 12, 56, 16, () -> Text.literal("< Back"), null, null,
                () -> { detail = null; clearAndInit(); }));
        add(new FancyButton(width - 62, 12, 50, 16, () -> Text.literal("Done"), null, null, this::close));

        int cx = Math.max(20, width / 2 - 160);
        int cw = Math.min(320, width - cx * 2);
        int y = 90;
        add(new FancySlider(cx, y, cw, 22, "Size", 50, 200, 10, "%",
                () -> Math.round(XenoHud.scaleOf(e) * 100),
                v -> {
                    if (XenomizedConfig.cfg.hudScale == null) XenomizedConfig.cfg.hudScale = new java.util.HashMap<>();
                    XenomizedConfig.cfg.hudScale.put(e.id, v / 100f);
                },
                XenomizedConfig::save));
        add(new FancyButton(cx, y + 30, cw, 22, () -> Text.literal(e.label),
                () -> e.enabled()
                        ? Text.literal("ON").formatted(Formatting.GREEN)
                        : Text.literal("OFF").formatted(Formatting.RED),
                e::enabled,
                () -> { e.setEnabled(!e.enabled()); XenomizedConfig.save(); }));
        add(new FancyButton(cx, y + 60, cw, 22, () -> Text.literal("Reset position"), null, null,
                () -> { XenomizedConfig.cfg.hudPos.remove(e.id); XenomizedConfig.save(); }));
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        XenoBackground.draw(ctx, width, height);
        ctx.fill(0, 0, width, height, 0x90000000);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        if (detail == null) {
            ctx.drawTextWithShadow(textRenderer, Text.literal("HUD").formatted(Formatting.BOLD, Formatting.AQUA),
                    width / 2 - 20, 60 - 2 - 4 + 0, 0xFFFFFFFF);
        } else {
            ctx.drawTextWithShadow(textRenderer, Text.literal(detail.label).formatted(Formatting.BOLD, Formatting.AQUA),
                    width / 2 - textRenderer.getWidth(detail.label) / 2, 60, 0xFFFFFFFF);
        }
    }

    @Override
    public void close() {
        detail = null;
        XenomizedConfig.save();
        client.setScreen(parent);
    }
}
