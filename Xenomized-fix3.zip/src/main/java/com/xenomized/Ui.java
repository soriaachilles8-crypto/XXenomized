package com.xenomized;

import net.minecraft.client.gui.DrawContext;

/** Small drawing helpers: rounded panels built from non-overlapping rectangles. */
public final class Ui {
    private Ui() {}

    /** Rounded panel with a 1px border. */
    public static void panel(DrawContext c, int x, int y, int w, int h, int fill, int border) {
        c.fill(x + 2, y, x + w - 2, y + 1, border);
        c.fill(x + 2, y + h - 1, x + w - 2, y + h, border);
        c.fill(x, y + 2, x + 1, y + h - 2, border);
        c.fill(x + w - 1, y + 2, x + w, y + h - 2, border);
        c.fill(x + 1, y + 1, x + 2, y + 2, border);
        c.fill(x + w - 2, y + 1, x + w - 1, y + 2, border);
        c.fill(x + 1, y + h - 2, x + 2, y + h - 1, border);
        c.fill(x + w - 2, y + h - 2, x + w - 1, y + h - 1, border);
        c.fill(x + 2, y + 1, x + w - 2, y + h - 1, fill);
        c.fill(x + 1, y + 2, x + 2, y + h - 2, fill);
        c.fill(x + w - 2, y + 2, x + w - 1, y + h - 2, fill);
    }

    /** Rounded filled box with no border. */
    public static void rounded(DrawContext c, int x, int y, int w, int h, int fill) {
        c.fill(x + 1, y, x + w - 1, y + 1, fill);
        c.fill(x, y + 1, x + w, y + h - 1, fill);
        c.fill(x + 1, y + h - 1, x + w - 1, y + h, fill);
    }
}
