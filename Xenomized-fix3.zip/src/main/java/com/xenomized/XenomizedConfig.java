package com.xenomized;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class XenomizedConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("xenomized.json");

    public static XenomizedConfig cfg = new XenomizedConfig();

    // ---- Performance / Visuals (applied to vanilla options while enabled) ----
    public boolean enabled = false;
    public int renderDistance = 8;
    public int simDistance = 6;
    public int maxFps = 260; // 260 = unlimited in vanilla
    public boolean fastGraphics = true;
    public boolean minimalParticles = true;
    public boolean noClouds = true;
    public boolean noShadows = true;
    public boolean noSmoothLighting = false;
    public boolean noBiomeBlend = true;

    // ---- Entity culling (render only) ----
    public boolean cullEntities = false;
    public int cullDistance = 64;
    public boolean cullItems = true;
    public boolean cullArmorStands = true;

    // ---- Stack limits (render only). 0 = off, otherwise 1 or 3 ----
    public int limitArmorStands = 0;
    public int limitTntMinecarts = 0;
    public int limitWindCharges = 0;
    public int threshold = 10; // only kicks in when a pile is bigger than this

    // ---- Title screen ----
    public boolean customTitle = true;
    public String lastServer = "";

    // ---- Menus ----
    public boolean menuBackground = true;

    // ---- HUD ----
    public boolean hudFps = true;
    public boolean hudCps = true;
    public boolean hudCoords = true;
    public boolean hudPing = false;
    public boolean hudKeys = true;
    public boolean hudArmor = true;
    public boolean hudBackground = true;
    public java.util.Map<String, float[]> hudPos = new java.util.HashMap<>();

    // Your original settings, so Restore can put them back
    public Saved saved = null;

    public static class Saved {
        public int view;
        public int sim;
        public int fps;
        public String particles;
        public String clouds;
        public String graphics;
        public boolean shadows;
        public boolean ao;
        public int biome;
    }

    public static void load() {
        try {
            if (Files.exists(FILE)) {
                XenomizedConfig loaded = GSON.fromJson(Files.readString(FILE), XenomizedConfig.class);
                if (loaded != null) cfg = loaded;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        try {
            Files.writeString(FILE, GSON.toJson(cfg));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void apply() {
        GameOptions o = MinecraftClient.getInstance().options;
        XenomizedConfig c = cfg;

        if (c.saved == null) {
            Saved s = new Saved();
            s.view = o.getViewDistance().getValue();
            s.sim = o.getSimulationDistance().getValue();
            s.fps = o.getMaxFps().getValue();
            s.particles = o.getParticles().getValue().name();
            s.clouds = o.getCloudRenderMode().getValue().name();
            s.graphics = o.getPreset().getValue().name();
            s.shadows = o.getEntityShadows().getValue();
            s.ao = o.getAo().getValue();
            s.biome = o.getBiomeBlendRadius().getValue();
            c.saved = s;
        }

        // Apply the preset first so our individual settings below win over it
        if (c.fastGraphics) o.applyGraphicsMode(GraphicsMode.FAST);
        o.getViewDistance().setValue(c.renderDistance);
        o.getSimulationDistance().setValue(c.simDistance);
        o.getMaxFps().setValue(c.maxFps);
        if (c.minimalParticles) o.getParticles().setValue(ParticlesMode.MINIMAL);
        if (c.noClouds) o.getCloudRenderMode().setValue(CloudRenderMode.OFF);
        if (c.noShadows) o.getEntityShadows().setValue(false);
        if (c.noSmoothLighting) o.getAo().setValue(false);
        if (c.noBiomeBlend) o.getBiomeBlendRadius().setValue(0);

        o.write();
        save();
    }

    public static void restore() {
        XenomizedConfig c = cfg;
        if (c.saved == null) return;
        GameOptions o = MinecraftClient.getInstance().options;
        Saved s = c.saved;

        GraphicsMode g = GraphicsMode.valueOf(s.graphics);
        if (g != GraphicsMode.CUSTOM) o.applyGraphicsMode(g);
        o.getViewDistance().setValue(s.view);
        o.getSimulationDistance().setValue(s.sim);
        o.getMaxFps().setValue(s.fps);
        o.getParticles().setValue(ParticlesMode.valueOf(s.particles));
        o.getCloudRenderMode().setValue(CloudRenderMode.valueOf(s.clouds));
        o.getEntityShadows().setValue(s.shadows);
        o.getAo().setValue(s.ao);
        o.getBiomeBlendRadius().setValue(s.biome);

        c.saved = null;
        o.write();
        save();
    }

    /** Call after any Performance/Visuals change. */
    public static void reapply() {
        if (cfg.enabled) {
            restore();
            apply();
        } else {
            save();
        }
    }

    private static void enableAndApply() {
        restore();
        cfg.enabled = true;
        apply();
    }

    public static void presetBalanced() {
        XenomizedConfig c = cfg;
        c.renderDistance = 10; c.simDistance = 8; c.maxFps = 260;
        c.fastGraphics = true; c.minimalParticles = false; c.noClouds = true;
        c.noShadows = true; c.noSmoothLighting = false; c.noBiomeBlend = false;
        c.cullEntities = true; c.cullDistance = 64; c.cullItems = true; c.cullArmorStands = false;
        c.limitArmorStands = 3; c.limitTntMinecarts = 3; c.limitWindCharges = 3; c.threshold = 10;
        enableAndApply();
    }

    public static void presetMax() {
        XenomizedConfig c = cfg;
        c.renderDistance = 6; c.simDistance = 5; c.maxFps = 260;
        c.fastGraphics = true; c.minimalParticles = true; c.noClouds = true;
        c.noShadows = true; c.noSmoothLighting = true; c.noBiomeBlend = true;
        c.cullEntities = true; c.cullDistance = 32; c.cullItems = true; c.cullArmorStands = true;
        c.limitArmorStands = 1; c.limitTntMinecarts = 1; c.limitWindCharges = 1; c.threshold = 5;
        enableAndApply();
    }

    public static void resetAll() {
        restore();
        XenomizedConfig c = cfg;
        c.enabled = false;
        c.cullEntities = false;
        c.limitArmorStands = 0; c.limitTntMinecarts = 0; c.limitWindCharges = 0;
        save();
    }
}
